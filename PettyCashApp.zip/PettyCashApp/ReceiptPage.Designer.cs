﻿namespace PettyCashApplication
{
    partial class ReceiptPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReceiptPage));
            this.dgrReceiptView = new eSurvey.Controls.ESSGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblEssReceiptID = new eSurvey.Controls.ESSLabel();
            this.lblEssDate = new eSurvey.Controls.ESSLabel();
            this.dtpEssDate = new eSurvey.Controls.ESSDateTimePicker();
            this.txtEssReceiptID = new eSurvey.Controls.ESSTextBox();
            this.btnEssSave = new eSurvey.Controls.ESSButton();
            this.btnEssClose = new eSurvey.Controls.ESSButton();
            this.btnEssClear = new eSurvey.Controls.ESSButton();
            this.btnEssDelete = new eSurvey.Controls.ESSButton();
            this.lblEssPersonID = new eSurvey.Controls.ESSLabel();
            this.lblEssCount = new eSurvey.Controls.ESSLabel();
            this.cmbEssPerson = new eSurvey.Controls.ESSComboBox();
            this.txtEssCount = new eSurvey.Controls.ESSTextBox();
            this.txtEssAmount = new eSurvey.Controls.ESSTextBox();
            this.lblEssAmount = new eSurvey.Controls.ESSLabel();
            this.btnEsseExport = new eSurvey.Controls.ESSButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgrReceiptView)).BeginInit();
            this.SuspendLayout();
            // 
            // dgrReceiptView
            // 
            this.dgrReceiptView.AllowUserToAddRows = false;
            this.dgrReceiptView.AllowUserToDeleteRows = false;
            this.dgrReceiptView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrReceiptView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgrReceiptView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrReceiptView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrReceiptView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgrReceiptView.Location = new System.Drawing.Point(12, 165);
            this.dgrReceiptView.MaxRows = 1;
            this.dgrReceiptView.Name = "dgrReceiptView";
            this.dgrReceiptView.ReadOnly = true;
            this.dgrReceiptView.RowTemplate.Height = 24;
            this.dgrReceiptView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrReceiptView.Size = new System.Drawing.Size(708, 244);
            this.dgrReceiptView.TabIndex = 2;
            this.dgrReceiptView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrReceiptView_CellClick);
            this.dgrReceiptView.SelectionChanged += new System.EventHandler(this.dgrReceiptView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // lblEssReceiptID
            // 
            this.lblEssReceiptID.AutoSize = true;
            this.lblEssReceiptID.Location = new System.Drawing.Point(8, 24);
            this.lblEssReceiptID.Name = "lblEssReceiptID";
            this.lblEssReceiptID.Size = new System.Drawing.Size(86, 23);
            this.lblEssReceiptID.TabIndex = 3;
            this.lblEssReceiptID.Text = "Receipt ID";
            // 
            // lblEssDate
            // 
            this.lblEssDate.AutoSize = true;
            this.lblEssDate.Location = new System.Drawing.Point(8, 72);
            this.lblEssDate.Name = "lblEssDate";
            this.lblEssDate.Size = new System.Drawing.Size(45, 23);
            this.lblEssDate.TabIndex = 4;
            this.lblEssDate.Text = "Date";
            // 
            // dtpEssDate
            // 
            this.dtpEssDate.Location = new System.Drawing.Point(102, 68);
            this.dtpEssDate.Name = "dtpEssDate";
            this.dtpEssDate.Size = new System.Drawing.Size(240, 26);
            this.dtpEssDate.TabIndex = 5;
            // 
            // txtEssReceiptID
            // 
            this.txtEssReceiptID.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssReceiptID.Location = new System.Drawing.Point(100, 21);
            this.txtEssReceiptID.Name = "txtEssReceiptID";
            this.txtEssReceiptID.Size = new System.Drawing.Size(240, 26);
            this.txtEssReceiptID.TabIndex = 6;
            this.txtEssReceiptID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssReceiptID.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // 
            // btnEssSave
            // 
            this.btnEssSave.Location = new System.Drawing.Point(158, 119);
            this.btnEssSave.Name = "btnEssSave";
            this.btnEssSave.Size = new System.Drawing.Size(119, 30);
            this.btnEssSave.TabIndex = 7;
            this.btnEssSave.Text = "Save";
            this.btnEssSave.UseVisualStyleBackColor = true;
            this.btnEssSave.Click += new System.EventHandler(this.btnEssSave_Click);
            // 
            // btnEssClose
            // 
            this.btnEssClose.Location = new System.Drawing.Point(601, 120);
            this.btnEssClose.Name = "btnEssClose";
            this.btnEssClose.Size = new System.Drawing.Size(119, 30);
            this.btnEssClose.TabIndex = 8;
            this.btnEssClose.Text = "Close";
            this.btnEssClose.UseVisualStyleBackColor = true;
            this.btnEssClose.Click += new System.EventHandler(this.btnEssClose_Click);
            // 
            // btnEssClear
            // 
            this.btnEssClear.Location = new System.Drawing.Point(12, 120);
            this.btnEssClear.Name = "btnEssClear";
            this.btnEssClear.Size = new System.Drawing.Size(119, 30);
            this.btnEssClear.TabIndex = 9;
            this.btnEssClear.Text = "New";
            this.btnEssClear.UseVisualStyleBackColor = true;
            this.btnEssClear.Click += new System.EventHandler(this.btnEssClear_Click);
            // 
            // btnEssDelete
            // 
            this.btnEssDelete.Location = new System.Drawing.Point(306, 120);
            this.btnEssDelete.Name = "btnEssDelete";
            this.btnEssDelete.Size = new System.Drawing.Size(119, 30);
            this.btnEssDelete.TabIndex = 10;
            this.btnEssDelete.Text = "Delete";
            this.btnEssDelete.UseVisualStyleBackColor = true;
            this.btnEssDelete.Click += new System.EventHandler(this.btnEssDelete_Click);
            // 
            // lblEssPersonID
            // 
            this.lblEssPersonID.AutoSize = true;
            this.lblEssPersonID.Location = new System.Drawing.Point(379, 24);
            this.lblEssPersonID.Name = "lblEssPersonID";
            this.lblEssPersonID.Size = new System.Drawing.Size(60, 23);
            this.lblEssPersonID.TabIndex = 11;
            this.lblEssPersonID.Text = "Person";
            // 
            // lblEssCount
            // 
            this.lblEssCount.AutoSize = true;
            this.lblEssCount.Location = new System.Drawing.Point(583, 418);
            this.lblEssCount.Name = "lblEssCount";
            this.lblEssCount.Size = new System.Drawing.Size(60, 23);
            this.lblEssCount.TabIndex = 16;
            this.lblEssCount.Text = "Count:";
            // 
            // cmbEssPerson
            // 
            this.cmbEssPerson.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEssPerson.FormattingEnabled = true;
            this.cmbEssPerson.Location = new System.Drawing.Point(480, 17);
            this.cmbEssPerson.Name = "cmbEssPerson";
            this.cmbEssPerson.Size = new System.Drawing.Size(240, 30);
            this.cmbEssPerson.TabIndex = 18;
            this.cmbEssPerson.SelectedIndexChanged += new System.EventHandler(this.cmbEssPerson_SelectedIndexChanged);
            // 
            // txtEssCount
            // 
            this.txtEssCount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Location = new System.Drawing.Point(660, 415);
            this.txtEssCount.Name = "txtEssCount";
            this.txtEssCount.Size = new System.Drawing.Size(60, 26);
            this.txtEssCount.TabIndex = 21;
            this.txtEssCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // 
            // txtEssAmount
            // 
            this.txtEssAmount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssAmount.Location = new System.Drawing.Point(480, 65);
            this.txtEssAmount.Name = "txtEssAmount";
            this.txtEssAmount.Size = new System.Drawing.Size(240, 26);
            this.txtEssAmount.TabIndex = 23;
            this.txtEssAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssAmount.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // 
            // lblEssAmount
            // 
            this.lblEssAmount.AutoSize = true;
            this.lblEssAmount.Location = new System.Drawing.Point(379, 68);
            this.lblEssAmount.Name = "lblEssAmount";
            this.lblEssAmount.Size = new System.Drawing.Size(69, 23);
            this.lblEssAmount.TabIndex = 22;
            this.lblEssAmount.Text = "Amount";
            // 
            // btnEsseExport
            // 
            this.btnEsseExport.Location = new System.Drawing.Point(456, 119);
            this.btnEsseExport.Name = "btnEsseExport";
            this.btnEsseExport.Size = new System.Drawing.Size(119, 31);
            this.btnEsseExport.TabIndex = 24;
            this.btnEsseExport.Text = "Export";
            this.btnEsseExport.UseVisualStyleBackColor = true;
            this.btnEsseExport.Click += new System.EventHandler(this.btnEsseExport_Click);
            // 
            // ReceiptPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 453);
            this.Controls.Add(this.btnEsseExport);
            this.Controls.Add(this.txtEssAmount);
            this.Controls.Add(this.lblEssAmount);
            this.Controls.Add(this.txtEssCount);
            this.Controls.Add(this.cmbEssPerson);
            this.Controls.Add(this.lblEssCount);
            this.Controls.Add(this.lblEssPersonID);
            this.Controls.Add(this.btnEssDelete);
            this.Controls.Add(this.btnEssClear);
            this.Controls.Add(this.btnEssClose);
            this.Controls.Add(this.btnEssSave);
            this.Controls.Add(this.txtEssReceiptID);
            this.Controls.Add(this.dtpEssDate);
            this.Controls.Add(this.lblEssDate);
            this.Controls.Add(this.lblEssReceiptID);
            this.Controls.Add(this.dgrReceiptView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReceiptPage";
            this.Text = "Receipt Details";
            this.Load += new System.EventHandler(this.ReceiptPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrReceiptView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private eSurvey.Controls.ESSGridView dgrReceiptView;
        private eSurvey.Controls.ESSLabel lblEssReceiptID;
        private eSurvey.Controls.ESSLabel lblEssDate;
        private eSurvey.Controls.ESSDateTimePicker dtpEssDate;
        private eSurvey.Controls.ESSTextBox txtEssReceiptID;
        private eSurvey.Controls.ESSButton btnEssSave;
        private eSurvey.Controls.ESSButton btnEssClose;
        private eSurvey.Controls.ESSButton btnEssClear;
        private eSurvey.Controls.ESSButton btnEssDelete;
        private eSurvey.Controls.ESSLabel lblEssPersonID;
        private eSurvey.Controls.ESSLabel lblEssCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private eSurvey.Controls.ESSComboBox cmbEssPerson;
        private eSurvey.Controls.ESSTextBox txtEssCount;
        private eSurvey.Controls.ESSTextBox txtEssAmount;
        private eSurvey.Controls.ESSLabel lblEssAmount;
        private eSurvey.Controls.ESSButton btnEsseExport;
    }
}