﻿namespace PettyCashApplication
{
    partial class Person
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Person));
            this.lblEssExpenseMasterName = new eSurvey.Controls.ESSLabel();
            this.dgrEssExpenseManager = new eSurvey.Controls.ESSGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtEssExpenseMasterName = new eSurvey.Controls.ESSTextBox();
            this.txtEssExpenseMasterID = new eSurvey.Controls.ESSTextBox();
            this.lblEssExpenseMasterID = new eSurvey.Controls.ESSLabel();
            this.btnEssSave = new eSurvey.Controls.ESSButton();
            this.btnEssDelete = new eSurvey.Controls.ESSButton();
            this.btnEssClose = new eSurvey.Controls.ESSButton();
            this.btnEssClear = new eSurvey.Controls.ESSButton();
            this.txtEssCount = new eSurvey.Controls.ESSTextBox();
            this.lblEssCount = new eSurvey.Controls.ESSLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssExpenseManager)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEssExpenseMasterName
            // 
            this.lblEssExpenseMasterName.AutoSize = true;
            this.lblEssExpenseMasterName.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEssExpenseMasterName.Location = new System.Drawing.Point(12, 71);
            this.lblEssExpenseMasterName.Name = "lblEssExpenseMasterName";
            this.lblEssExpenseMasterName.Size = new System.Drawing.Size(216, 25);
            this.lblEssExpenseMasterName.TabIndex = 1;
            this.lblEssExpenseMasterName.Text = "Enter Person Name:";
            // 
            // dgrEssExpenseManager
            // 
            this.dgrEssExpenseManager.AllowUserToAddRows = false;
            this.dgrEssExpenseManager.AllowUserToDeleteRows = false;
            this.dgrEssExpenseManager.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrEssExpenseManager.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgrEssExpenseManager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrEssExpenseManager.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrEssExpenseManager.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgrEssExpenseManager.Location = new System.Drawing.Point(12, 179);
            this.dgrEssExpenseManager.MaxRows = 1;
            this.dgrEssExpenseManager.Name = "dgrEssExpenseManager";
            this.dgrEssExpenseManager.ReadOnly = true;
            this.dgrEssExpenseManager.RowTemplate.Height = 24;
            this.dgrEssExpenseManager.Size = new System.Drawing.Size(708, 216);
            this.dgrEssExpenseManager.TabIndex = 6;
            this.dgrEssExpenseManager.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrEssExpenseManager_CellClick);
            this.dgrEssExpenseManager.SelectionChanged += new System.EventHandler(this.dgrEssExpenseManager_SelectionChanged_1);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // txtEssExpenseMasterName
            // 
            this.txtEssExpenseMasterName.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssExpenseMasterName.Location = new System.Drawing.Point(328, 70);
            this.txtEssExpenseMasterName.Name = "txtEssExpenseMasterName";
            this.txtEssExpenseMasterName.Size = new System.Drawing.Size(392, 26);
            this.txtEssExpenseMasterName.TabIndex = 7;
            // 
            // txtEssExpenseMasterID
            // 
            this.txtEssExpenseMasterID.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssExpenseMasterID.Location = new System.Drawing.Point(328, 27);
            this.txtEssExpenseMasterID.Name = "txtEssExpenseMasterID";
            this.txtEssExpenseMasterID.Size = new System.Drawing.Size(392, 26);
            this.txtEssExpenseMasterID.TabIndex = 9;
            this.txtEssExpenseMasterID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssExpenseMasterID.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            this.txtEssExpenseMasterID.TextChanged += new System.EventHandler(this.txtEssExpenseMasterID_TextChanged);
            // 
            // lblEssExpenseMasterID
            // 
            this.lblEssExpenseMasterID.AutoSize = true;
            this.lblEssExpenseMasterID.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEssExpenseMasterID.Location = new System.Drawing.Point(12, 28);
            this.lblEssExpenseMasterID.Name = "lblEssExpenseMasterID";
            this.lblEssExpenseMasterID.Size = new System.Drawing.Size(181, 25);
            this.lblEssExpenseMasterID.TabIndex = 8;
            this.lblEssExpenseMasterID.Text = "Enter Person ID:";
            // 
            // btnEssSave
            // 
            this.btnEssSave.Location = new System.Drawing.Point(204, 123);
            this.btnEssSave.Name = "btnEssSave";
            this.btnEssSave.Size = new System.Drawing.Size(136, 35);
            this.btnEssSave.TabIndex = 10;
            this.btnEssSave.Text = "Save";
            this.btnEssSave.UseVisualStyleBackColor = true;
            this.btnEssSave.Click += new System.EventHandler(this.btnEssSave_Click);
            // 
            // btnEssDelete
            // 
            this.btnEssDelete.Location = new System.Drawing.Point(397, 123);
            this.btnEssDelete.Name = "btnEssDelete";
            this.btnEssDelete.Size = new System.Drawing.Size(136, 35);
            this.btnEssDelete.TabIndex = 11;
            this.btnEssDelete.Text = "Delete";
            this.btnEssDelete.UseVisualStyleBackColor = true;
            this.btnEssDelete.Click += new System.EventHandler(this.btnEssDelete_Click_1);
            // 
            // btnEssClose
            // 
            this.btnEssClose.Location = new System.Drawing.Point(584, 123);
            this.btnEssClose.Name = "btnEssClose";
            this.btnEssClose.Size = new System.Drawing.Size(136, 35);
            this.btnEssClose.TabIndex = 12;
            this.btnEssClose.Text = "Close";
            this.btnEssClose.UseVisualStyleBackColor = true;
            this.btnEssClose.Click += new System.EventHandler(this.btnEssClose_Click);
            // 
            // btnEssClear
            // 
            this.btnEssClear.Location = new System.Drawing.Point(17, 123);
            this.btnEssClear.Name = "btnEssClear";
            this.btnEssClear.Size = new System.Drawing.Size(136, 35);
            this.btnEssClear.TabIndex = 13;
            this.btnEssClear.Text = "New";
            this.btnEssClear.UseVisualStyleBackColor = true;
            this.btnEssClear.Click += new System.EventHandler(this.btnEssClear_Click);
            // 
            // txtEssCount
            // 
            this.txtEssCount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Location = new System.Drawing.Point(670, 415);
            this.txtEssCount.Name = "txtEssCount";
            this.txtEssCount.Size = new System.Drawing.Size(50, 26);
            this.txtEssCount.TabIndex = 15;
            // 
            // lblEssCount
            // 
            this.lblEssCount.AutoSize = true;
            this.lblEssCount.Location = new System.Drawing.Point(604, 415);
            this.lblEssCount.Name = "lblEssCount";
            this.lblEssCount.Size = new System.Drawing.Size(60, 23);
            this.lblEssCount.TabIndex = 14;
            this.lblEssCount.Text = "Count:";
            // 
            // Person
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 453);
            this.Controls.Add(this.txtEssCount);
            this.Controls.Add(this.lblEssCount);
            this.Controls.Add(this.btnEssClear);
            this.Controls.Add(this.btnEssClose);
            this.Controls.Add(this.btnEssDelete);
            this.Controls.Add(this.btnEssSave);
            this.Controls.Add(this.txtEssExpenseMasterID);
            this.Controls.Add(this.lblEssExpenseMasterID);
            this.Controls.Add(this.txtEssExpenseMasterName);
            this.Controls.Add(this.dgrEssExpenseManager);
            this.Controls.Add(this.lblEssExpenseMasterName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Person";
            this.Text = "Person Details";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssExpenseManager)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private eSurvey.Controls.ESSLabel lblEssExpenseMasterName;
        private eSurvey.Controls.ESSGridView dgrEssExpenseManager;
        private eSurvey.Controls.ESSTextBox txtEssExpenseMasterName;
        private eSurvey.Controls.ESSTextBox txtEssExpenseMasterID;
        private eSurvey.Controls.ESSLabel lblEssExpenseMasterID;
        private eSurvey.Controls.ESSButton btnEssSave;
        private eSurvey.Controls.ESSButton btnEssDelete;
        private eSurvey.Controls.ESSButton btnEssClose;
        private eSurvey.Controls.ESSButton btnEssClear;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private eSurvey.Controls.ESSTextBox txtEssCount;
        private eSurvey.Controls.ESSLabel lblEssCount;
    }
}

