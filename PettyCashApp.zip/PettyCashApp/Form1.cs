﻿using System;
using System.Windows.Forms;
using PettyCashApplication; // Ensure this is the correct namespace for your forms

namespace PettyCashApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Maximize the form by default
            this.WindowState = FormWindowState.Maximized;

            // Disable resizing of the form
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = true;
            this.MinimizeBox = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Maximize the form by default
            this.WindowState = FormWindowState.Maximized;

            // Disable resizing of the form
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Set Form1 as an MDI container
            this.IsMdiContainer = true;
        }

        private void receiptToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ReceiptSearch receiptSearch = new ReceiptSearch();
            OpenChildForm(receiptSearch);
            receiptSearch.Show(); 
        }

        private void expenseToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ExpenseSearch expenseSearch = new ExpenseSearch();
            OpenChildForm(expenseSearch);
            expenseSearch.Show(); 
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About aboutForm = new About
            {
                FormBorderStyle = FormBorderStyle.FixedSingle,
                MaximizeBox = false,
                MinimizeBox = false
            };
            aboutForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Application", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void OpenChildForm(Form childForm)
        {
            // Close all existing child forms
            foreach (Form form in this.MdiChildren)
            {
                form.Close();
            }

            // Open the new child form
            childForm.MdiParent = this;
            childForm.Show();
        }

        private void personToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Person personForm = new Person();
            OpenChildForm(personForm);
            personForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void receiptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReceiptPage receiptForm = new ReceiptPage();
            OpenChildForm(receiptForm);
            receiptForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void categoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CategoryPage categoryForm = new CategoryPage();
            OpenChildForm(categoryForm);
            categoryForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void expenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExpensePage expenseForm = new ExpensePage();
            OpenChildForm(expenseForm);
            expenseForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }


    }
}
