﻿namespace PettyCashApp
{
    partial class ReceiptSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReceiptSearch));
            this.cmbEssPerson = new eSurvey.Controls.ESSComboBox();
            this.lblEssName = new eSurvey.Controls.ESSLabel();
            this.btnEssFilter = new eSurvey.Controls.ESSButton();
            this.btnEssExport = new eSurvey.Controls.ESSButton();
            this.lblEssDate = new eSurvey.Controls.ESSLabel();
            this.dtpEssEnd = new eSurvey.Controls.ESSDateTimePicker();
            this.dgrEssReceiptSearch = new eSurvey.Controls.ESSGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtEssCount = new eSurvey.Controls.ESSTextBox();
            this.lblEssCount = new eSurvey.Controls.ESSLabel();
            this.dtpEssStart = new eSurvey.Controls.ESSDateTimePicker();
            this.lblEssTo = new eSurvey.Controls.ESSLabel();
            this.btnEssClear = new eSurvey.Controls.ESSButton();
            this.btnEssClose = new eSurvey.Controls.ESSButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssReceiptSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbEssPerson
            // 
            this.cmbEssPerson.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEssPerson.FormattingEnabled = true;
            this.cmbEssPerson.Location = new System.Drawing.Point(90, 18);
            this.cmbEssPerson.Name = "cmbEssPerson";
            this.cmbEssPerson.Size = new System.Drawing.Size(160, 30);
            this.cmbEssPerson.TabIndex = 1;
            this.cmbEssPerson.SelectedIndexChanged += new System.EventHandler(this.cmbEssPerson_SelectedIndexChanged);
            // 
            // lblEssName
            // 
            this.lblEssName.AutoSize = true;
            this.lblEssName.Location = new System.Drawing.Point(12, 21);
            this.lblEssName.Name = "lblEssName";
            this.lblEssName.Size = new System.Drawing.Size(59, 23);
            this.lblEssName.TabIndex = 2;
            this.lblEssName.Text = "Name:";
            // 
            // btnEssFilter
            // 
            this.btnEssFilter.Location = new System.Drawing.Point(204, 64);
            this.btnEssFilter.Name = "btnEssFilter";
            this.btnEssFilter.Size = new System.Drawing.Size(135, 33);
            this.btnEssFilter.TabIndex = 3;
            this.btnEssFilter.Text = "Filter";
            this.btnEssFilter.UseVisualStyleBackColor = true;
            this.btnEssFilter.Click += new System.EventHandler(this.btnEssFilter_Click);
            // 
            // btnEssExport
            // 
            this.btnEssExport.Location = new System.Drawing.Point(396, 64);
            this.btnEssExport.Name = "btnEssExport";
            this.btnEssExport.Size = new System.Drawing.Size(135, 33);
            this.btnEssExport.TabIndex = 4;
            this.btnEssExport.Text = "Export";
            this.btnEssExport.UseVisualStyleBackColor = true;
            this.btnEssExport.Click += new System.EventHandler(this.btnEssExport_Click);
            // 
            // lblEssDate
            // 
            this.lblEssDate.AutoSize = true;
            this.lblEssDate.Location = new System.Drawing.Point(265, 22);
            this.lblEssDate.Name = "lblEssDate";
            this.lblEssDate.Size = new System.Drawing.Size(51, 23);
            this.lblEssDate.TabIndex = 5;
            this.lblEssDate.Text = "Date:";
            // 
            // dtpEssEnd
            // 
            this.dtpEssEnd.Location = new System.Drawing.Point(559, 18);
            this.dtpEssEnd.Name = "dtpEssEnd";
            this.dtpEssEnd.Size = new System.Drawing.Size(161, 26);
            this.dtpEssEnd.TabIndex = 6;
            // 
            // dgrEssReceiptSearch
            // 
            this.dgrEssReceiptSearch.AllowUserToAddRows = false;
            this.dgrEssReceiptSearch.AllowUserToDeleteRows = false;
            this.dgrEssReceiptSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrEssReceiptSearch.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgrEssReceiptSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrEssReceiptSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrEssReceiptSearch.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgrEssReceiptSearch.Location = new System.Drawing.Point(12, 113);
            this.dgrEssReceiptSearch.MaxRows = 1;
            this.dgrEssReceiptSearch.Name = "dgrEssReceiptSearch";
            this.dgrEssReceiptSearch.ReadOnly = true;
            this.dgrEssReceiptSearch.RowTemplate.Height = 24;
            this.dgrEssReceiptSearch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrEssReceiptSearch.Size = new System.Drawing.Size(708, 295);
            this.dgrEssReceiptSearch.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // txtEssCount
            // 
            this.txtEssCount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Location = new System.Drawing.Point(659, 417);
            this.txtEssCount.Name = "txtEssCount";
            this.txtEssCount.Size = new System.Drawing.Size(61, 26);
            this.txtEssCount.TabIndex = 11;
            // 
            // lblEssCount
            // 
            this.lblEssCount.AutoSize = true;
            this.lblEssCount.Location = new System.Drawing.Point(593, 421);
            this.lblEssCount.Name = "lblEssCount";
            this.lblEssCount.Size = new System.Drawing.Size(60, 23);
            this.lblEssCount.TabIndex = 12;
            this.lblEssCount.Text = "Count:";
            // 
            // dtpEssStart
            // 
            this.dtpEssStart.Location = new System.Drawing.Point(334, 18);
            this.dtpEssStart.Name = "dtpEssStart";
            this.dtpEssStart.Size = new System.Drawing.Size(161, 26);
            this.dtpEssStart.TabIndex = 13;
            this.dtpEssStart.ValueChanged += new System.EventHandler(this.dtpEssStart_ValueChanged);
            // 
            // lblEssTo
            // 
            this.lblEssTo.AutoSize = true;
            this.lblEssTo.Location = new System.Drawing.Point(511, 21);
            this.lblEssTo.Name = "lblEssTo";
            this.lblEssTo.Size = new System.Drawing.Size(27, 23);
            this.lblEssTo.TabIndex = 14;
            this.lblEssTo.Text = "To";
            this.lblEssTo.Click += new System.EventHandler(this.lblEssTo_Click);
            // 
            // btnEssClear
            // 
            this.btnEssClear.Location = new System.Drawing.Point(16, 64);
            this.btnEssClear.Name = "btnEssClear";
            this.btnEssClear.Size = new System.Drawing.Size(135, 33);
            this.btnEssClear.TabIndex = 15;
            this.btnEssClear.Text = "New";
            this.btnEssClear.UseVisualStyleBackColor = true;
            this.btnEssClear.Click += new System.EventHandler(this.btnEssClear_Click);
            // 
            // btnEssClose
            // 
            this.btnEssClose.Location = new System.Drawing.Point(585, 64);
            this.btnEssClose.Name = "btnEssClose";
            this.btnEssClose.Size = new System.Drawing.Size(135, 33);
            this.btnEssClose.TabIndex = 16;
            this.btnEssClose.Text = "Close";
            this.btnEssClose.UseVisualStyleBackColor = true;
            this.btnEssClose.Click += new System.EventHandler(this.btnEssClose_Click);
            // 
            // ReceiptSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 453);
            this.Controls.Add(this.btnEssClose);
            this.Controls.Add(this.btnEssClear);
            this.Controls.Add(this.lblEssTo);
            this.Controls.Add(this.dtpEssStart);
            this.Controls.Add(this.lblEssCount);
            this.Controls.Add(this.txtEssCount);
            this.Controls.Add(this.dgrEssReceiptSearch);
            this.Controls.Add(this.dtpEssEnd);
            this.Controls.Add(this.lblEssDate);
            this.Controls.Add(this.btnEssExport);
            this.Controls.Add(this.btnEssFilter);
            this.Controls.Add(this.lblEssName);
            this.Controls.Add(this.cmbEssPerson);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReceiptSearch";
            this.Text = "Receipt Search";
            this.Load += new System.EventHandler(this.ReceiptSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssReceiptSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private eSurvey.Controls.ESSComboBox cmbEssPerson;
        private eSurvey.Controls.ESSLabel lblEssName;
        private eSurvey.Controls.ESSButton btnEssFilter;
        private eSurvey.Controls.ESSButton btnEssExport;
        private eSurvey.Controls.ESSLabel lblEssDate;
        private eSurvey.Controls.ESSDateTimePicker dtpEssEnd;
        private eSurvey.Controls.ESSGridView dgrEssReceiptSearch;
        private eSurvey.Controls.ESSTextBox txtEssCount;
        private eSurvey.Controls.ESSLabel lblEssCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private eSurvey.Controls.ESSDateTimePicker dtpEssStart;
        private eSurvey.Controls.ESSLabel lblEssTo;
        private eSurvey.Controls.ESSButton btnEssClear;
        private eSurvey.Controls.ESSButton btnEssClose;
    }
}