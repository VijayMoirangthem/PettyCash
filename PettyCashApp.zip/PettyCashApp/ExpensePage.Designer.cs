﻿namespace PettyCashApplication
{
    partial class ExpensePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExpensePage));
            this.dgrEssExpenseView = new eSurvey.Controls.ESSGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEssExport = new eSurvey.Controls.ESSButton();
            this.lblEssExpenseID = new eSurvey.Controls.ESSLabel();
            this.txtEssExpenseID = new eSurvey.Controls.ESSTextBox();
            this.cmbEssPerson = new eSurvey.Controls.ESSComboBox();
            this.txtEssAmount = new eSurvey.Controls.ESSTextBox();
            this.lblEssExpense = new eSurvey.Controls.ESSLabel();
            this.lblEssPerson = new eSurvey.Controls.ESSLabel();
            this.lblEssBalance = new eSurvey.Controls.ESSLabel();
            this.txtEssBalance = new eSurvey.Controls.ESSTextBox();
            this.lblEssCategory = new eSurvey.Controls.ESSLabel();
            this.cmbEssCategory = new eSurvey.Controls.ESSComboBox();
            this.btnEssClear = new eSurvey.Controls.ESSButton();
            this.btnEssClose = new eSurvey.Controls.ESSButton();
            this.btnEssSave = new eSurvey.Controls.ESSButton();
            this.btnEssDelete = new eSurvey.Controls.ESSButton();
            this.lblEssDate = new eSurvey.Controls.ESSLabel();
            this.dtpEssDate = new eSurvey.Controls.ESSDateTimePicker();
            this.lblEssCount = new eSurvey.Controls.ESSLabel();
            this.txtEssCount = new eSurvey.Controls.ESSTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssExpenseView)).BeginInit();
            this.SuspendLayout();
            // 
            // dgrEssExpenseView
            // 
            this.dgrEssExpenseView.AllowUserToAddRows = false;
            this.dgrEssExpenseView.AllowUserToDeleteRows = false;
            this.dgrEssExpenseView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrEssExpenseView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgrEssExpenseView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrEssExpenseView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrEssExpenseView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgrEssExpenseView.Location = new System.Drawing.Point(12, 159);
            this.dgrEssExpenseView.MaxRows = 1;
            this.dgrEssExpenseView.Name = "dgrEssExpenseView";
            this.dgrEssExpenseView.ReadOnly = true;
            this.dgrEssExpenseView.RowTemplate.Height = 24;
            this.dgrEssExpenseView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrEssExpenseView.Size = new System.Drawing.Size(708, 259);
            this.dgrEssExpenseView.TabIndex = 0;
            this.dgrEssExpenseView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrEssExpenseView_CellClick);
            this.dgrEssExpenseView.SelectionChanged += new System.EventHandler(this.grdEssExpenseView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // btnEssExport
            // 
            this.btnEssExport.Location = new System.Drawing.Point(548, 66);
            this.btnEssExport.Name = "btnEssExport";
            this.btnEssExport.Size = new System.Drawing.Size(172, 29);
            this.btnEssExport.TabIndex = 2;
            this.btnEssExport.Text = "Export Excel";
            this.btnEssExport.UseVisualStyleBackColor = true;
            this.btnEssExport.Click += new System.EventHandler(this.btnEssExcel_Click);
            // 
            // lblEssExpenseID
            // 
            this.lblEssExpenseID.AutoSize = true;
            this.lblEssExpenseID.Location = new System.Drawing.Point(12, 24);
            this.lblEssExpenseID.Name = "lblEssExpenseID";
            this.lblEssExpenseID.Size = new System.Drawing.Size(92, 23);
            this.lblEssExpenseID.TabIndex = 4;
            this.lblEssExpenseID.Text = "Expense ID";
            // 
            // txtEssExpenseID
            // 
            this.txtEssExpenseID.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssExpenseID.Location = new System.Drawing.Point(155, 21);
            this.txtEssExpenseID.Name = "txtEssExpenseID";
            this.txtEssExpenseID.Size = new System.Drawing.Size(102, 26);
            this.txtEssExpenseID.TabIndex = 5;
            this.txtEssExpenseID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssExpenseID.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // 
            // cmbEssPerson
            // 
            this.cmbEssPerson.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEssPerson.FormattingEnabled = true;
            this.cmbEssPerson.Location = new System.Drawing.Point(360, 22);
            this.cmbEssPerson.Name = "cmbEssPerson";
            this.cmbEssPerson.Size = new System.Drawing.Size(130, 30);
            this.cmbEssPerson.TabIndex = 6;
            // txtEssAmount
            // 
            this.txtEssAmount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssAmount.Location = new System.Drawing.Point(156, 69);
            this.txtEssAmount.Name = "txtEssAmount";
            this.txtEssAmount.Size = new System.Drawing.Size(101, 26);
            this.txtEssAmount.TabIndex = 8;
            this.txtEssAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssAmount.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // 
            // lblEssExpense
            // 
            this.lblEssExpense.AutoSize = true;
            this.lblEssExpense.Location = new System.Drawing.Point(12, 72);
            this.lblEssExpense.Name = "lblEssExpense";
            this.lblEssExpense.Size = new System.Drawing.Size(135, 23);
            this.lblEssExpense.TabIndex = 7;
            this.lblEssExpense.Text = "Expense Amount";
            // 
            // lblEssPerson
            // 
            this.lblEssPerson.AutoSize = true;
            this.lblEssPerson.Location = new System.Drawing.Point(273, 24);
            this.lblEssPerson.Name = "lblEssPerson";
            this.lblEssPerson.Size = new System.Drawing.Size(60, 23);
            this.lblEssPerson.TabIndex = 9;
            this.lblEssPerson.Text = "Person";
            // 
            // lblEssBalance
            // 
            this.lblEssBalance.AutoSize = true;
            this.lblEssBalance.Location = new System.Drawing.Point(12, 425);
            this.lblEssBalance.Name = "lblEssBalance";
            this.lblEssBalance.Size = new System.Drawing.Size(112, 23);
            this.lblEssBalance.TabIndex = 10;
            this.lblEssBalance.Text = "Total Balance";
            // 
            // txtEssBalance
            // 
            this.txtEssBalance.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtEssBalance.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssBalance.Location = new System.Drawing.Point(130, 422);
            this.txtEssBalance.Name = "txtEssBalance";
            this.txtEssBalance.Size = new System.Drawing.Size(102, 26);
            this.txtEssBalance.TabIndex = 11;
            this.txtEssBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssBalance.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // 
            // lblEssCategory
            // 
            this.lblEssCategory.AutoSize = true;
            this.lblEssCategory.Location = new System.Drawing.Point(273, 72);
            this.lblEssCategory.Name = "lblEssCategory";
            this.lblEssCategory.Size = new System.Drawing.Size(78, 23);
            this.lblEssCategory.TabIndex = 15;
            this.lblEssCategory.Text = "Category";
            // 
            // cmbEssCategory
            // 
            this.cmbEssCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEssCategory.FormattingEnabled = true;
            this.cmbEssCategory.Location = new System.Drawing.Point(360, 69);
            this.cmbEssCategory.Name = "cmbEssCategory";
            this.cmbEssCategory.Size = new System.Drawing.Size(130, 30);
            this.cmbEssCategory.TabIndex = 14;
            // 
            // btnEssClear
            // 
            this.btnEssClear.Location = new System.Drawing.Point(12, 112);
            this.btnEssClear.Name = "btnEssClear";
            this.btnEssClear.Size = new System.Drawing.Size(108, 30);
            this.btnEssClear.TabIndex = 17;
            this.btnEssClear.Text = "New";
            this.btnEssClear.UseVisualStyleBackColor = true;
            this.btnEssClear.Click += new System.EventHandler(this.btnEssClear_Click);
            // 
            // btnEssClose
            // 
            this.btnEssClose.Location = new System.Drawing.Point(612, 113);
            this.btnEssClose.Name = "btnEssClose";
            this.btnEssClose.Size = new System.Drawing.Size(108, 30);
            this.btnEssClose.TabIndex = 18;
            this.btnEssClose.Text = "Close";
            this.btnEssClose.UseVisualStyleBackColor = true;
            this.btnEssClose.Click += new System.EventHandler(this.btnEssClose_Click);
            // 
            // btnEssSave
            // 
            this.btnEssSave.Location = new System.Drawing.Point(212, 112);
            this.btnEssSave.Name = "btnEssSave";
            this.btnEssSave.Size = new System.Drawing.Size(108, 30);
            this.btnEssSave.TabIndex = 19;
            this.btnEssSave.Text = "Save";
            this.btnEssSave.UseVisualStyleBackColor = true;
            this.btnEssSave.Click += new System.EventHandler(this.btnEssSave_Click);
            // 
            // btnEssDelete
            // 
            this.btnEssDelete.Location = new System.Drawing.Point(411, 112);
            this.btnEssDelete.Name = "btnEssDelete";
            this.btnEssDelete.Size = new System.Drawing.Size(108, 30);
            this.btnEssDelete.TabIndex = 20;
            this.btnEssDelete.Text = "Delete";
            this.btnEssDelete.UseVisualStyleBackColor = true;
            this.btnEssDelete.Click += new System.EventHandler(this.btnEssDelete_Click);
            // 
            // lblEssDate
            // 
            this.lblEssDate.AutoSize = true;
            this.lblEssDate.Location = new System.Drawing.Point(502, 25);
            this.lblEssDate.Name = "lblEssDate";
            this.lblEssDate.Size = new System.Drawing.Size(45, 23);
            this.lblEssDate.TabIndex = 22;
            this.lblEssDate.Text = "Date";
            // 
            // dtpEssDate
            // 
            this.dtpEssDate.Location = new System.Drawing.Point(548, 21);
            this.dtpEssDate.Name = "dtpEssDate";
            this.dtpEssDate.Size = new System.Drawing.Size(172, 26);
            this.dtpEssDate.TabIndex = 23;
            // 
            // lblEssCount
            // 
            this.lblEssCount.AutoSize = true;
            this.lblEssCount.Location = new System.Drawing.Point(604, 425);
            this.lblEssCount.Name = "lblEssCount";
            this.lblEssCount.Size = new System.Drawing.Size(54, 23);
            this.lblEssCount.TabIndex = 24;
            this.lblEssCount.Text = "Count";
            // 
            // txtEssCount
            // 
            this.txtEssCount.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtEssCount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Location = new System.Drawing.Point(664, 422);
            this.txtEssCount.Name = "txtEssCount";
            this.txtEssCount.Size = new System.Drawing.Size(56, 26);
            this.txtEssCount.TabIndex = 25;
            this.txtEssCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // ExpensePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 453);
            this.Controls.Add(this.txtEssCount);
            this.Controls.Add(this.lblEssCount);
            this.Controls.Add(this.dtpEssDate);
            this.Controls.Add(this.lblEssDate);
            this.Controls.Add(this.btnEssDelete);
            this.Controls.Add(this.btnEssSave);
            this.Controls.Add(this.btnEssClose);
            this.Controls.Add(this.btnEssClear);
            this.Controls.Add(this.lblEssCategory);
            this.Controls.Add(this.cmbEssCategory);
            this.Controls.Add(this.txtEssBalance);
            this.Controls.Add(this.lblEssBalance);
            this.Controls.Add(this.lblEssPerson);
            this.Controls.Add(this.txtEssAmount);
            this.Controls.Add(this.lblEssExpense);
            this.Controls.Add(this.cmbEssPerson);
            this.Controls.Add(this.txtEssExpenseID);
            this.Controls.Add(this.lblEssExpenseID);
            this.Controls.Add(this.btnEssExport);
            this.Controls.Add(this.dgrEssExpenseView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ExpensePage";
            this.Text = "Expense Details";
            this.Load += new System.EventHandler(this.ExpensePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssExpenseView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private eSurvey.Controls.ESSGridView dgrEssExpenseView;
        private eSurvey.Controls.ESSButton btnEssExport;
        private eSurvey.Controls.ESSLabel lblEssExpenseID;
        private eSurvey.Controls.ESSTextBox txtEssExpenseID;
        private eSurvey.Controls.ESSComboBox cmbEssPerson;
        private eSurvey.Controls.ESSTextBox txtEssAmount;
        private eSurvey.Controls.ESSLabel lblEssExpense;
        private eSurvey.Controls.ESSLabel lblEssPerson;
        private eSurvey.Controls.ESSLabel lblEssBalance;
        private eSurvey.Controls.ESSTextBox txtEssBalance;
        private eSurvey.Controls.ESSLabel lblEssCategory;
        private eSurvey.Controls.ESSComboBox cmbEssCategory;
        private eSurvey.Controls.ESSButton btnEssClear;
        private eSurvey.Controls.ESSButton btnEssClose;
        private eSurvey.Controls.ESSButton btnEssSave;
        private eSurvey.Controls.ESSButton btnEssDelete;
        private eSurvey.Controls.ESSLabel lblEssDate;
        private eSurvey.Controls.ESSDateTimePicker dtpEssDate;
        private eSurvey.Controls.ESSLabel lblEssCount;
        private eSurvey.Controls.ESSTextBox txtEssCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    }
}