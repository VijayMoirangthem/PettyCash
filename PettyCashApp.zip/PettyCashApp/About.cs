﻿using System;
using System.Windows.Forms;
using System.Diagnostics; 

namespace PettyCashApplication
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove maximize and minimize buttons, only close button should be visible
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void About_Load(object sender, EventArgs e)
        {
            // No need to maximize the window state here
        }


        private void essLinkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://github.com/VijayMoirangthem",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link: " + ex.Message);
            }
        }

    }
}
