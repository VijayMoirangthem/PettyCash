﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using PettyCashApplication;
using PettyCashApp;
using ESSExcelExport;
using System.IO;

namespace PettyCashApp
{
    public partial class ReceiptSearch : Form
    {
        private DataSet dataSet;
        private SQLiteDataAdapter adapter;
        private SQLiteConnection connection;
        private string strCS = @"URI=file:" + Application.StartupPath + "\\PettyCash.db";

        public ReceiptSearch()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove maximize and minimize buttons, only close button should be visible
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            InitializeEssBoundGridView();
            txtEssCount.ReadOnly = true;
        }

        private void ReceiptSearch_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadPersons();
            InitializeAdapter();
            ClearForm();
        }

        private void InitializeAdapter()
        {
            adapter = new SQLiteDataAdapter("SELECT * FROM Receipt", strCS);
            SQLiteCommandBuilder builder = new SQLiteCommandBuilder(adapter);

            adapter.InsertCommand = builder.GetInsertCommand();
            adapter.UpdateCommand = builder.GetUpdateCommand();
            adapter.DeleteCommand = builder.GetDeleteCommand();
        }

        private void ClearForm()
        {
            cmbEssPerson.SelectedIndex = -1; // Ensure no value is selected by default
            dtpEssStart.Value = DateTime.Now;
            dtpEssEnd.Value = DateTime.Now;
            dgrEssReceiptSearch.ClearSelection();
            LoadData(); // Optionally refresh data after clearing
        }

        private void InitializeEssBoundGridView()
        {
            dgrEssReceiptSearch.AutoGenerateColumns = false;
            dgrEssReceiptSearch.Columns.Clear();

            dgrEssReceiptSearch.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ReceiptID",
                DataPropertyName = "ReceiptID",
                HeaderText = "Receipt ID",
                ReadOnly = true
            });
            dgrEssReceiptSearch.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PersonName",
                DataPropertyName = "PersonName",
                HeaderText = "Person Name"
            });
            dgrEssReceiptSearch.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Date",
                DataPropertyName = "Date",
                HeaderText = "Date"
            });
            dgrEssReceiptSearch.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Amount",
                DataPropertyName = "Amount",
                HeaderText = "Amount"
            });
        }

        private void LoadData()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                string query = "SELECT r.ReceiptID, p.Name AS PersonName, r.Date, r.Amount " +
                               "FROM Receipt r " +
                               "JOIN Person p ON r.PersonID = p.PersonID";

                adapter = new SQLiteDataAdapter(query, connection);

                dataSet = new DataSet();
                adapter.Fill(dataSet, "Receipt");
                dataSet.Tables["Receipt"].PrimaryKey = new DataColumn[] { dataSet.Tables["Receipt"].Columns["ReceiptID"] };

                dgrEssReceiptSearch.DataSource = dataSet.Tables["Receipt"];
                txtEssCount.Text = dataSet.Tables["Receipt"].Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void LoadPersons()
        {
            try
            {
                using (var connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    var command = new SQLiteCommand("SELECT PersonID, Name FROM Person", connection);
                    var reader = command.ExecuteReader();
                    var items = new List<ComboBoxItem>();
                    while (reader.Read())
                    {
                        items.Add(new ComboBoxItem
                        {
                            Text = reader["Name"].ToString(),
                            Value = Convert.ToInt32(reader["PersonID"])
                        });
                    }
                    cmbEssPerson.DisplayMember = "Text";
                    cmbEssPerson.ValueMember = "Value";
                    cmbEssPerson.DataSource = items;
                    cmbEssPerson.SelectedIndex = -1; // Ensure no value is selected by default
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading persons: " + ex.Message);
            }
        }

        private void FilterData()
        {
            ComboBoxItem selectedItem = cmbEssPerson.SelectedItem as ComboBoxItem;
            int? nameFilter = selectedItem != null ? (int?)selectedItem.Value : null;
            DateTime startDate = dtpEssStart.Value.Date;
            DateTime endDate = dtpEssEnd.Value.Date;

            using (var connection = new SQLiteConnection(strCS))
            {
                string query = "SELECT r.ReceiptID, p.Name AS PersonName, r.Date, r.Amount " +
                               "FROM Receipt r " +
                               "JOIN Person p ON r.PersonID = p.PersonID " +
                               "WHERE (@Name IS NULL OR p.PersonID = @Name) " +
                               "AND r.Date BETWEEN @StartDate AND @EndDate";

                using (var cmd = new SQLiteCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Name", nameFilter.HasValue ? (object)nameFilter.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@StartDate", startDate);
                    cmd.Parameters.AddWithValue("@EndDate", endDate);

                    DataTable dt = new DataTable();
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                        dgrEssReceiptSearch.DataSource = dt;
                        txtEssCount.Text = dt.Rows.Count.ToString();
                    }
                }
            }
        }

        private void btnEssFilter_Click(object sender, EventArgs e)
        {
            FilterData();
        }

        private void btnEssExport_Click(object sender, EventArgs e)
        {
            string strFileName = Path.Combine(Application.StartupPath, "ReceiptSearchExportTemplate.xlsx");
            ExcelExport eport = new ExcelExport(ExcelAppType.MicrosoftExcel, false);
            eport.OpenWorkbook(strFileName);
            eport.SetVisible(false);
            DataTable dt = (DataTable)dgrEssReceiptSearch.DataSource;
            if (dt != null && dt.Rows.Count > 0)
            {
                int Rowspos = 2;
                foreach (DataRow row in dt.Rows) // Use Rows instead of Select for accurate row access
                {
                    eport.SetCellContent(Rowspos, 1, row["ReceiptID"]);
                    eport.SetCellContent(Rowspos, 2, row["PersonName"]);
                    eport.SetCellContent(Rowspos, 3, row["Date"]);
                    eport.SetCellContent(Rowspos, 4, row["Amount"]);
                    Rowspos++;
                }
            }
            eport.SetVisible(true);
            MessageBox.Show("Export Success");
        }

        private void btnEssClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void cmbEssPerson_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterDataByName();
        }

        private void FilterDataByName()
        {
            ComboBoxItem selectedItem = cmbEssPerson.SelectedItem as ComboBoxItem;
            int? nameFilter = selectedItem != null ? (int?)selectedItem.Value : null;

            // Set the start date to January 1, 1900
            DateTime startDate = new DateTime(1900, 1, 1);
            DateTime endDate = dtpEssEnd.Value.Date;

            // Set the DateTimePickers to the desired values
            dtpEssStart.Value = startDate;
            dtpEssEnd.Value = DateTime.Now;

            using (var connection = new SQLiteConnection(strCS))
            {
                string query = "SELECT r.ReceiptID, p.Name AS PersonName, r.Date, r.Amount " +
                               "FROM Receipt r " +
                               "JOIN Person p ON r.PersonID = p.PersonID " +
                               "WHERE (@Name IS NULL OR p.PersonID = @Name) " +
                               "AND r.Date BETWEEN @StartDate AND @EndDate";

                using (var cmd = new SQLiteCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Name", nameFilter.HasValue ? (object)nameFilter.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@StartDate", startDate);
                    cmd.Parameters.AddWithValue("@EndDate", endDate);

                    DataTable dt = new DataTable();
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                        dgrEssReceiptSearch.DataSource = dt;
                        txtEssCount.Text = dt.Rows.Count.ToString();
                    }
                }
            }
        }


        private void dtpEssStart_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnEssClose_Click(object sender, EventArgs e)
        {
            {
                this.Close();
            }
        }

        private void lblEssTo_Click(object sender, EventArgs e)
        {

        }

    }

    class ComboBoxItem
    {
        public string Text { get; set; }
        public int Value { get; set; }

        public override string ToString()
        {
            return Text; // To display the text in the ComboBox
        }
    }
}
