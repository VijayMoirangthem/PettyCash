﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using PettyCashApplication;
using PettyCashApp;
using ESSExcelExport;
using System.IO;

namespace PettyCashApp
{
    public partial class ExpenseSearch : Form
    {
        private DataSet dataSet;
        private SQLiteDataAdapter adapter;
        private SQLiteConnection connection;
        private string strCS = @"URI=file:" + Application.StartupPath + "\\PettyCash.db";

        public ExpenseSearch()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove maximize and minimize buttons, only close button should be visible
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            InitializeEssBoundGridView();
            txtEssCount.ReadOnly = true;
            this.Load += new EventHandler(ExpenseSearch_Load);
        }

        private void ExpenseSearch_Load(object sender, EventArgs e)
        {
            {
                LoadData();
                LoadPersons();
                LoadCategories();
                InitializeAdapter();
                ClearForm();
                dgrEssExpenseView.ClearSelection();
            }
        }

        private void InitializeAdapter()
        {
            adapter = new SQLiteDataAdapter("SELECT * FROM Expense", strCS);
            SQLiteCommandBuilder builder = new SQLiteCommandBuilder(adapter);

            adapter.InsertCommand = builder.GetInsertCommand();
            adapter.UpdateCommand = builder.GetUpdateCommand();
            adapter.DeleteCommand = builder.GetDeleteCommand();
        }

        private void ClearForm()
        {
            txtEssCount.Clear();
            cmbEssPerson.SelectedIndex = -1;
            cmbEssCategory.SelectedIndex = -1;
            dtpEssStart.Value = DateTime.Now;
            dtpEssEnd.Value = DateTime.Now;
            dgrEssExpenseView.ClearSelection();
            LoadData();
        }

        private void InitializeEssBoundGridView()
        {
            dgrEssExpenseView.AutoGenerateColumns = false;
            dgrEssExpenseView.Columns.Clear();

            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ExpenseID",
                DataPropertyName = "ExpenseID",
                HeaderText = "Expense ID",
                ReadOnly = true
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PersonName",
                DataPropertyName = "PersonName",
                HeaderText = "Person Name"
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "CategoryName",
                DataPropertyName = "CategoryName",
                HeaderText = "Category Name"
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Amount",
                DataPropertyName = "Amount",
                HeaderText = "Amount"
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Date",
                DataPropertyName = "Date",
                HeaderText = "Date"
            });
        }

        private void dgrEssExpenseView_SelectionChanged(object sender, EventArgs e)
        {
            if (dgrEssExpenseView.SelectedRows.Count > 0)
            {
                int expenseID = Convert.ToInt32(dgrEssExpenseView.SelectedRows[0].Cells["ExpenseID"].Value);
                // Do something with the selected ExpenseID if needed
            }
        }

        private void LoadData()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                string query = "SELECT e.ExpenseID, p.Name AS PersonName, c.CategoryName AS CategoryName, e.Amount, e.Date " +
                               "FROM Expense e " +
                               "JOIN Person p ON e.PersonID = p.PersonID " +
                               "JOIN Category c ON e.CategoryID = c.CategoryID";

                adapter = new SQLiteDataAdapter(query, connection);

                dataSet = new DataSet();
                adapter.Fill(dataSet, "Expense");
                dataSet.Tables["Expense"].PrimaryKey = new DataColumn[] { dataSet.Tables["Expense"].Columns["ExpenseID"] };

                dgrEssExpenseView.DataSource = dataSet.Tables["Expense"];
                txtEssCount.Text = dataSet.Tables["Expense"].Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void btnEssClose_Click(object sender, EventArgs e)
        {
            {
                this.Close();
            }
        }

        private void btnEssClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void FilterData()
        {
            ComboBoxItem selectedPerson = cmbEssPerson.SelectedItem as ComboBoxItem;
            int? personFilter = selectedPerson != null ? (int?)selectedPerson.Value : null;

            ComboBoxCategory selectedItem = cmbEssCategory.SelectedItem as ComboBoxCategory;
            int? categoryFilter = selectedItem != null ? (int?)selectedItem.Value : null;

            DateTime startDate = dtpEssStart.Value.Date;
            DateTime endDate = dtpEssEnd.Value.Date;

            using (var connection = new SQLiteConnection(strCS))
            {
                var filters = new List<string>();
                var parameters = new Dictionary<string, object>();

                if (personFilter.HasValue)
                {
                    filters.Add("e.PersonID = @PersonID");
                    parameters.Add("@PersonID", personFilter.Value);
                }

                if (categoryFilter.HasValue)
                {
                    filters.Add("e.CategoryID = @CategoryID");
                    parameters.Add("@CategoryID", categoryFilter.Value);
                }

                if (startDate != DateTime.MinValue && endDate != DateTime.MinValue)
                {
                    filters.Add("e.Date BETWEEN @StartDate AND @EndDate");
                    parameters.Add("@StartDate", startDate);
                    parameters.Add("@EndDate", endDate);
                }

                string filterQuery = filters.Count > 0 ? "WHERE " + string.Join(" AND ", filters.ToArray()) : "";

                string query = "SELECT e.ExpenseID, p.Name AS PersonName, c.CategoryName, e.Amount, e.Date " +
                               "FROM Expense e " +
                               "JOIN Person p ON e.PersonID = p.PersonID " +
                               "JOIN Category c ON e.CategoryID = c.CategoryID " +
                               filterQuery;

                using (var cmd = new SQLiteCommand(query, connection))
                {
                    foreach (var param in parameters)
                    {
                        cmd.Parameters.AddWithValue(param.Key, param.Value);
                    }

                    DataTable dt = new DataTable();
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                        dgrEssExpenseView.DataSource = dt;
                        txtEssCount.Text = dt.Rows.Count.ToString();
                    }
                }
            }
        }


        private void FilterDataByName()
        {
            ComboBoxItem selectedItem = cmbEssPerson.SelectedItem as ComboBoxItem;
            int? nameFilter = selectedItem != null ? (int?)selectedItem.Value : null;

            using (var connection = new SQLiteConnection(strCS))
            {
                string query = "SELECT e.ExpenseID, p.Name AS PersonName, c.CategoryName, e.Amount, e.Date " +
                               "FROM Expense e " +
                               "JOIN Person p ON e.PersonID = p.PersonID " +
                               "JOIN Category c ON e.CategoryID = c.CategoryID " +
                               "WHERE (@Name IS NULL OR e.PersonID = @Name)";

                using (var cmd = new SQLiteCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Name", nameFilter.HasValue ? (object)nameFilter.Value : DBNull.Value);

                    DataTable dt = new DataTable();
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                        dgrEssExpenseView.DataSource = dt;
                        txtEssCount.Text = dt.Rows.Count.ToString();
                    }
                }
            }
        }

        private void FilterDataByCategory()
        {
            ComboBoxCategory selectedItem = cmbEssCategory.SelectedItem as ComboBoxCategory;
            int? categoryFilter = selectedItem != null ? (int?)selectedItem.Value : null;

            using (var connection = new SQLiteConnection(strCS))
            {
                string query = "SELECT e.ExpenseID, p.Name AS PersonName, c.CategoryName, e.Amount, e.Date " +
                               "FROM Expense e " +
                               "JOIN Person p ON e.PersonID = p.PersonID " +
                               "JOIN Category c ON e.CategoryID = c.CategoryID " +
                               "WHERE (@Category IS NULL OR e.CategoryID = @Category)";

                using (var cmd = new SQLiteCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Category", categoryFilter.HasValue ? (object)categoryFilter.Value : DBNull.Value);

                    DataTable dt = new DataTable();
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                        dgrEssExpenseView.DataSource = dt;
                        txtEssCount.Text = dt.Rows.Count.ToString();
                    }
                }
            }
        }

        private void cmbEssName_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterDataByName();
        }

        private void cmbEssCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            FilterDataByCategory();
        }

        private void btnEssFilter_Click(object sender, EventArgs e)
        {
            FilterData();
        }

        private void btnEssExport_Click(object sender, EventArgs e)
        {
            // Construct the dynamic path to the template file
            string strFileName = Path.Combine(Application.StartupPath, "ExpenseSearchExportTemplate.xlsx");
            ExcelExport eport = new ExcelExport(ExcelAppType.MicrosoftExcel, false);
            eport.OpenWorkbook(strFileName);
            eport.SetVisible(false);
            DataTable dt = (DataTable)dgrEssExpenseView.DataSource;
            if (dt != null && dt.Rows.Count > 0)
            {
                int Rowspos = 2;
                foreach (DataRow row in dt.Select())
                {
                    eport.SetCellContent(Rowspos, 1, row[0]);
                    eport.SetCellContent(Rowspos, 2, row[1]);
                    eport.SetCellContent(Rowspos, 3, row[2]);
                    eport.SetCellContent(Rowspos, 4, row[3]);
                    eport.SetCellContent(Rowspos, 5, row[4]);
                    Rowspos++;
                }
            }
            eport.SetVisible(true);
            MessageBox.Show("Export Success");
        }

        private void LoadPersons()
        {
            try
            {
                using (var connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    var command = new SQLiteCommand("SELECT PersonID, Name FROM Person", connection);
                    var reader = command.ExecuteReader();
                    var items = new List<ComboBoxItem>();
                    while (reader.Read())
                    {
                        items.Add(new ComboBoxItem
                        {
                            Text = reader["Name"].ToString(),
                            Value = Convert.ToInt32(reader["PersonID"])
                        });
                    }
                    cmbEssPerson.DisplayMember = "Text";
                    cmbEssPerson.ValueMember = "Value";
                    cmbEssPerson.DataSource = items;
                    cmbEssPerson.SelectedIndex = -1; // Ensure no value is selected by default
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading persons: " + ex.Message);
            }
        }

        private void LoadCategories()
        {
            try
            {
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    string query = "SELECT CategoryID, CategoryName FROM Category";
                    using (SQLiteCommand command = new SQLiteCommand(query, connection))
                    {
                        SQLiteDataReader reader = command.ExecuteReader();
                        var items = new List<ComboBoxCategory>();
                        while (reader.Read())
                        {
                            items.Add(new ComboBoxCategory
                            {
                                Text = reader["CategoryName"].ToString(),
                                Value = Convert.ToInt32(reader["CategoryID"])
                            });
                        }
                        cmbEssCategory.DisplayMember = "Text";
                        cmbEssCategory.ValueMember = "Value";
                        cmbEssCategory.DataSource = items;
                        cmbEssCategory.SelectedIndex = -1; // Ensure no value is selected by default
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading categories: " + ex.Message);
            }
        }


        private void LoadExpense()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                string strQuery = "SELECT e.ExpenseID, p.Name AS PersonName, c.CategoryName AS CategoryName, e.Amount, e.Date " +
                               "FROM Expense e " +
                               "JOIN Person p ON e.PersonID = p.PersonID " +
                               "JOIN Category c ON e.CategoryID = c.CategoryID";

                adapter = new SQLiteDataAdapter(strQuery, connection);

                dataSet = new DataSet();
                adapter.Fill(dataSet, "Expense");
                dataSet.Tables["Expense"].PrimaryKey = new DataColumn[] { dataSet.Tables["Expense"].Columns["ExpenseID"] };

                dgrEssExpenseView.DataSource = dataSet.Tables["Expense"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void lblEssCount_Click(object sender, EventArgs e)
        {

        }

        private void txtEssCount_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEssDate_Click(object sender, EventArgs e)
        {

        }

        private void dtpEssStart_ValueChanged(object sender, EventArgs e)
        {

        }
    }

    class ComboBoxCategory
    {
        public string Text { get; set; }
        public int Value { get; set; }

        public override string ToString()
        {
            return Text; // To display the text in the ComboBox
        }
    }

     

}
