﻿namespace PettyCashApp
{
    partial class ExpenseSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExpenseSearch));
            this.cmbEssPerson = new eSurvey.Controls.ESSComboBox();
            this.lblEssCount = new eSurvey.Controls.ESSLabel();
            this.txtEssCount = new eSurvey.Controls.ESSTextBox();
            this.btnEssExport = new eSurvey.Controls.ESSButton();
            this.btnEssClear = new eSurvey.Controls.ESSButton();
            this.dtpEssStart = new eSurvey.Controls.ESSDateTimePicker();
            this.dtpEssEnd = new eSurvey.Controls.ESSDateTimePicker();
            this.lblEssDate = new eSurvey.Controls.ESSLabel();
            this.btnEssFilter = new eSurvey.Controls.ESSButton();
            this.lblEssName = new eSurvey.Controls.ESSLabel();
            this.lblEssCategory = new eSurvey.Controls.ESSLabel();
            this.cmbEssCategory = new eSurvey.Controls.ESSComboBox();
            this.btnEssClose = new eSurvey.Controls.ESSButton();
            this.lblEssTo = new eSurvey.Controls.ESSLabel();
            this.dgrEssExpenseView = new eSurvey.Controls.ESSGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssExpenseView)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbEssPerson
            // 
            this.cmbEssPerson.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEssPerson.FormattingEnabled = true;
            this.cmbEssPerson.Location = new System.Drawing.Point(77, 18);
            this.cmbEssPerson.Name = "cmbEssPerson";
            this.cmbEssPerson.Size = new System.Drawing.Size(152, 30);
            this.cmbEssPerson.TabIndex = 2;
            this.cmbEssPerson.SelectedIndexChanged += new System.EventHandler(this.cmbEssName_SelectedIndexChanged);
            // 
            // lblEssCount
            // 
            this.lblEssCount.AutoSize = true;
            this.lblEssCount.Location = new System.Drawing.Point(593, 415);
            this.lblEssCount.Name = "lblEssCount";
            this.lblEssCount.Size = new System.Drawing.Size(60, 23);
            this.lblEssCount.TabIndex = 15;
            this.lblEssCount.Text = "Count:";
            this.lblEssCount.Click += new System.EventHandler(this.lblEssCount_Click);
            // 
            // txtEssCount
            // 
            this.txtEssCount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Location = new System.Drawing.Point(659, 415);
            this.txtEssCount.Name = "txtEssCount";
            this.txtEssCount.Size = new System.Drawing.Size(61, 26);
            this.txtEssCount.TabIndex = 14;
            this.txtEssCount.TextChanged += new System.EventHandler(this.txtEssCount_TextChanged);
            // 
            // btnEssExport
            // 
            this.btnEssExport.Location = new System.Drawing.Point(527, 62);
            this.btnEssExport.Name = "btnEssExport";
            this.btnEssExport.Size = new System.Drawing.Size(86, 33);
            this.btnEssExport.TabIndex = 13;
            this.btnEssExport.Text = "Export";
            this.btnEssExport.UseVisualStyleBackColor = true;
            this.btnEssExport.Click += new System.EventHandler(this.btnEssExport_Click);
            // 
            // btnEssClear
            // 
            this.btnEssClear.Location = new System.Drawing.Point(291, 62);
            this.btnEssClear.Name = "btnEssClear";
            this.btnEssClear.Size = new System.Drawing.Size(86, 33);
            this.btnEssClear.TabIndex = 19;
            this.btnEssClear.Text = "New";
            this.btnEssClear.UseVisualStyleBackColor = true;
            this.btnEssClear.Click += new System.EventHandler(this.btnEssClear_Click);
            // 
            // dtpEssStart
            // 
            this.dtpEssStart.Location = new System.Drawing.Point(308, 21);
            this.dtpEssStart.Name = "dtpEssStart";
            this.dtpEssStart.Size = new System.Drawing.Size(162, 26);
            this.dtpEssStart.TabIndex = 23;
            this.dtpEssStart.ValueChanged += new System.EventHandler(this.dtpEssStart_ValueChanged);
            // 
            // dtpEssEnd
            // 
            this.dtpEssEnd.Location = new System.Drawing.Point(558, 21);
            this.dtpEssEnd.Name = "dtpEssEnd";
            this.dtpEssEnd.Size = new System.Drawing.Size(162, 26);
            this.dtpEssEnd.TabIndex = 22;
            // 
            // lblEssDate
            // 
            this.lblEssDate.AutoSize = true;
            this.lblEssDate.Location = new System.Drawing.Point(235, 25);
            this.lblEssDate.Name = "lblEssDate";
            this.lblEssDate.Size = new System.Drawing.Size(51, 23);
            this.lblEssDate.TabIndex = 21;
            this.lblEssDate.Text = "Date:";
            this.lblEssDate.Click += new System.EventHandler(this.lblEssDate_Click);
            // 
            // btnEssFilter
            // 
            this.btnEssFilter.Location = new System.Drawing.Point(413, 62);
            this.btnEssFilter.Name = "btnEssFilter";
            this.btnEssFilter.Size = new System.Drawing.Size(86, 33);
            this.btnEssFilter.TabIndex = 20;
            this.btnEssFilter.Text = "Filter";
            this.btnEssFilter.UseVisualStyleBackColor = true;
            this.btnEssFilter.Click += new System.EventHandler(this.btnEssFilter_Click);
            // 
            // lblEssName
            // 
            this.lblEssName.AutoSize = true;
            this.lblEssName.Location = new System.Drawing.Point(12, 21);
            this.lblEssName.Name = "lblEssName";
            this.lblEssName.Size = new System.Drawing.Size(59, 23);
            this.lblEssName.TabIndex = 24;
            this.lblEssName.Text = "Name:";
            // 
            // lblEssCategory
            // 
            this.lblEssCategory.AutoSize = true;
            this.lblEssCategory.Location = new System.Drawing.Point(12, 65);
            this.lblEssCategory.Name = "lblEssCategory";
            this.lblEssCategory.Size = new System.Drawing.Size(84, 23);
            this.lblEssCategory.TabIndex = 26;
            this.lblEssCategory.Text = "Category:";
            // 
            // cmbEssCategory
            // 
            this.cmbEssCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEssCategory.FormattingEnabled = true;
            this.cmbEssCategory.Location = new System.Drawing.Point(112, 62);
            this.cmbEssCategory.Name = "cmbEssCategory";
            this.cmbEssCategory.Size = new System.Drawing.Size(143, 30);
            this.cmbEssCategory.TabIndex = 25;
            this.cmbEssCategory.SelectedIndexChanged += new System.EventHandler(this.cmbEssCategory_SelectedIndexChanged);
            // 
            // btnEssClose
            // 
            this.btnEssClose.Location = new System.Drawing.Point(634, 62);
            this.btnEssClose.Name = "btnEssClose";
            this.btnEssClose.Size = new System.Drawing.Size(86, 33);
            this.btnEssClose.TabIndex = 27;
            this.btnEssClose.Text = "Close";
            this.btnEssClose.UseVisualStyleBackColor = true;
            this.btnEssClose.Click += new System.EventHandler(this.btnEssClose_Click);
            // 
            // lblEssTo
            // 
            this.lblEssTo.AutoSize = true;
            this.lblEssTo.Location = new System.Drawing.Point(491, 25);
            this.lblEssTo.Name = "lblEssTo";
            this.lblEssTo.Size = new System.Drawing.Size(27, 23);
            this.lblEssTo.TabIndex = 28;
            this.lblEssTo.Text = "To";
            // 
            // dgrEssExpenseView
            // 
            this.dgrEssExpenseView.AllowUserToAddRows = false;
            this.dgrEssExpenseView.AllowUserToDeleteRows = false;
            this.dgrEssExpenseView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrEssExpenseView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgrEssExpenseView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrEssExpenseView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrEssExpenseView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgrEssExpenseView.Location = new System.Drawing.Point(12, 111);
            this.dgrEssExpenseView.MaxRows = 1;
            this.dgrEssExpenseView.Name = "dgrEssExpenseView";
            this.dgrEssExpenseView.ReadOnly = true;
            this.dgrEssExpenseView.RowTemplate.Height = 24;
            this.dgrEssExpenseView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrEssExpenseView.Size = new System.Drawing.Size(708, 298);
            this.dgrEssExpenseView.TabIndex = 29;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // ExpenseSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 453);
            this.Controls.Add(this.dgrEssExpenseView);
            this.Controls.Add(this.lblEssTo);
            this.Controls.Add(this.btnEssClose);
            this.Controls.Add(this.lblEssCategory);
            this.Controls.Add(this.cmbEssCategory);
            this.Controls.Add(this.lblEssName);
            this.Controls.Add(this.dtpEssStart);
            this.Controls.Add(this.dtpEssEnd);
            this.Controls.Add(this.lblEssDate);
            this.Controls.Add(this.btnEssFilter);
            this.Controls.Add(this.btnEssClear);
            this.Controls.Add(this.lblEssCount);
            this.Controls.Add(this.txtEssCount);
            this.Controls.Add(this.btnEssExport);
            this.Controls.Add(this.cmbEssPerson);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ExpenseSearch";
            this.Text = "Expense Search";
            this.Load += new System.EventHandler(this.ExpenseSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssExpenseView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private eSurvey.Controls.ESSComboBox cmbEssPerson;
        private eSurvey.Controls.ESSLabel lblEssCount;
        private eSurvey.Controls.ESSTextBox txtEssCount;
        private eSurvey.Controls.ESSButton btnEssExport;
        private eSurvey.Controls.ESSButton btnEssClear;
        private eSurvey.Controls.ESSDateTimePicker dtpEssStart;
        private eSurvey.Controls.ESSDateTimePicker dtpEssEnd;
        private eSurvey.Controls.ESSLabel lblEssDate;
        private eSurvey.Controls.ESSButton btnEssFilter;
        private eSurvey.Controls.ESSLabel lblEssName;
        private eSurvey.Controls.ESSLabel lblEssCategory;
        private eSurvey.Controls.ESSComboBox cmbEssCategory;
        private eSurvey.Controls.ESSButton btnEssClose;
        private eSurvey.Controls.ESSLabel lblEssTo;
        private eSurvey.Controls.ESSGridView dgrEssExpenseView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    }
}