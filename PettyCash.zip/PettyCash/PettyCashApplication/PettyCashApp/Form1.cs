﻿using System;
using System.Windows.Forms;
using PettyCashApplication; // Ensure this is the correct namespace for your forms

namespace PettyCashApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Maximize the form by default
            this.WindowState = FormWindowState.Maximized;

            // Disable resizing of the form
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = true;
            this.MinimizeBox = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

            // Maximize the form by default
            this.WindowState = FormWindowState.Maximized;

            // Disable resizing of the form
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Set Form1 as an MDI container
            this.IsMdiContainer = true;
        }

        
        private void personFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Person personForm = new Person();
            personForm.MdiParent = Form1.ActiveForm;

            personForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void receiptFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReceiptPage receiptForm = new ReceiptPage();
            receiptForm.MdiParent = Form1.ActiveForm;
            receiptForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void categoryFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CategoryPage categoryForm = new CategoryPage();
            categoryForm.MdiParent = Form1.ActiveForm;
            categoryForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void expenseFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExpensePage expenseForm = new ExpensePage();
            expenseForm.MdiParent = Form1.ActiveForm;
            expenseForm.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void receiptToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ReceiptSearch receiptSearch = new ReceiptSearch();
            receiptSearch.MdiParent = Form1.ActiveForm;
            receiptSearch.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void expenseToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ExpenseSearch expenseSearch = new ExpenseSearch();
            expenseSearch.MdiParent = Form1.ActiveForm;
            expenseSearch.Show(); // Open non-modally, or use ShowDialog() for modal
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About aboutForm = new About
            {
                FormBorderStyle = FormBorderStyle.FixedSingle,
                MaximizeBox = false,
                MinimizeBox = false
            };
            aboutForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit Application", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void personToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


    }
}
