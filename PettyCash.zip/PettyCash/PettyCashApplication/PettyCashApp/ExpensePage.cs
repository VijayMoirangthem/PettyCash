﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using PettyCashApplication;
using PettyCashApp;
using ESSExcelExport;

namespace PettyCashApplication
{
    public partial class ExpensePage : Form
    {
        private DataSet dataSet;
        private SQLiteDataAdapter adapter;
        private SQLiteConnection connection;
        private string strCS = @"URI=file:" + Application.StartupPath + "\\PettyCash.db";

        public ExpensePage()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove maximize and minimize buttons, only close button should be visible
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            InitializeEssBoundGridView();
            txtEssCount.ReadOnly = true;
            txtEssBalance.ReadOnly = true;
            this.Load += new EventHandler(ExpensePage_Load);
            LoadPersons();
            LoadCategories();
            UpdateCount();
            LoadExpense();
        }

        private void LoadExpense()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                string query = "SELECT e.ExpenseID, p.Name AS PersonName, c.CategoryName AS CategoryName, e.Amount, e.Date " +
                               "FROM Expense e " +
                               "JOIN Person p ON e.PersonID = p.PersonID " +
                               "JOIN Category c ON e.CategoryID = c.CategoryID";

                adapter = new SQLiteDataAdapter(query, connection);

                dataSet = new DataSet();
                adapter.Fill(dataSet, "Expense");
                dataSet.Tables["Expense"].PrimaryKey = new DataColumn[] { dataSet.Tables["Expense"].Columns["ExpenseID"] };

                dgrEssExpenseView.DataSource = dataSet.Tables["Expense"];
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void btnEssSave_Click(object sender, EventArgs e)
        {
            if (IsNullOrWhiteSpace(txtEssExpenseID.Text))
            {
                MessageBox.Show("Please enter Expense ID.");
                return;
            }

            if (cmbEssPerson.SelectedItem == null)
            {
                MessageBox.Show("Please select a Person.");
                return;
            }

            if (cmbEssCategory.SelectedItem == null)
            {
                MessageBox.Show("Please select a Category.");
                return;
            }

            if (IsNullOrWhiteSpace(txtEssAmount.Text))
            {
                MessageBox.Show("Please enter the Amount.");
                return;
            }

            if (dgrEssExpenseView.SelectedRows.Count > 0)
            {
                UpdateData();
            }
            else
            {
                InsertData();
            }
        }

        private bool CheckIfExistsID(string value)
        {
            bool exists = false;
            string query = "SELECT COUNT(1) FROM Expense WHERE ExpenseID = @value";

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(strCS))
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@value", value);
                        exists = Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking ID existence: " + ex.Message);
            }

            return exists;
        }

        private void InsertData()
        {
            string expenseID = txtEssExpenseID.Text.Trim();
            if (CheckIfExistsID(expenseID))
            {
                MessageBox.Show("The ID already exists. Please enter a different ID.");
                return;
            }

            try
            {
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    string insertQuery = "INSERT INTO Expense (ExpenseID, PersonID, CategoryID, Amount, Date) VALUES (@ExpenseID, @PersonID, @CategoryID, @Amount, @Date)";
                    using (SQLiteCommand cmd = new SQLiteCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ExpenseID", Convert.ToInt32(txtEssExpenseID.Text));
                        cmd.Parameters.AddWithValue("@PersonID", cmbEssPerson.SelectedValue);
                        cmd.Parameters.AddWithValue("@CategoryID", cmbEssCategory.SelectedValue);
                        cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtEssAmount.Text));
                        cmd.Parameters.AddWithValue("@Date", dtpEssDate.Value);

                        cmd.ExecuteNonQuery();
                    }
                }

                UpdatePersonBalance();
                LoadExpense();
                UpdateCount();
                ClearForm();
                MessageBox.Show("Expense data added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting expense data: " + ex.Message);
            }
        }

        private void UpdateData()
        {
            if (dgrEssExpenseView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to update.");
                return;
            }

            try
            {
                int oldExpenseID = Convert.ToInt32(dgrEssExpenseView.SelectedRows[0].Cells["ExpenseID"].Value);
                int newExpenseID = Convert.ToInt32(txtEssExpenseID.Text);

                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();

                    if (oldExpenseID != newExpenseID)
                    {
                        using (SQLiteTransaction transaction = connection.BeginTransaction())
                        {
                            try
                            {
                                string updateExpenseQuery = "UPDATE Expense SET ExpenseID = @NewExpenseID, PersonID = @PersonID, CategoryID = @CategoryID, Amount = @Amount, Date = @Date WHERE ExpenseID = @OldExpenseID";
                                using (SQLiteCommand cmd = new SQLiteCommand(updateExpenseQuery, connection))
                                {
                                    cmd.Parameters.AddWithValue("@NewExpenseID", newExpenseID);
                                    cmd.Parameters.AddWithValue("@OldExpenseID", oldExpenseID);
                                    cmd.Parameters.AddWithValue("@PersonID", cmbEssPerson.SelectedValue);
                                    cmd.Parameters.AddWithValue("@CategoryID", cmbEssCategory.SelectedValue);
                                    cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtEssAmount.Text));
                                    cmd.Parameters.AddWithValue("@Date", dtpEssDate.Value);

                                    cmd.ExecuteNonQuery();
                                }
                                transaction.Commit();
                            }
                            catch (Exception)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }
                    else
                    {
                        string updateQuery = "UPDATE Expense SET PersonID = @PersonID, CategoryID = @CategoryID, Amount = @Amount, Date = @Date WHERE ExpenseID = @ExpenseID";
                        using (SQLiteCommand cmd = new SQLiteCommand(updateQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@ExpenseID", newExpenseID);
                            cmd.Parameters.AddWithValue("@PersonID", cmbEssPerson.SelectedValue);
                            cmd.Parameters.AddWithValue("@CategoryID", cmbEssCategory.SelectedValue);
                            cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtEssAmount.Text));
                            cmd.Parameters.AddWithValue("@Date", dtpEssDate.Value);

                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                LoadExpense();
                UpdateCount();
                ClearForm();
                MessageBox.Show("Expense data updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating data: " + ex.Message);
            }
        }


        private void UpdatePersonBalance()
        {
            try
            {
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();

                    string personID = cmbEssPerson.SelectedValue.ToString();

                    string totalReceiptQuery = "SELECT SUM(Amount) FROM Receipt WHERE PersonID = @PersonID";
                    string totalExpenseQuery = "SELECT SUM(Amount) FROM Expense WHERE PersonID = @PersonID";

                    decimal totalReceipts = 0;
                    decimal totalExpenses = 0;

                    using (SQLiteCommand cmd = new SQLiteCommand(totalReceiptQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@PersonID", personID);
                        var result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            totalReceipts = Convert.ToDecimal(result);
                        }
                    }

                    using (SQLiteCommand cmd = new SQLiteCommand(totalExpenseQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@PersonID", personID);
                        var result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            totalExpenses = Convert.ToDecimal(result);
                        }
                    }

                    decimal balance = totalReceipts - totalExpenses;

                    string updateBalanceQuery = "UPDATE Person SET TotalBalance = @TotalBalance WHERE PersonID = @PersonID";
                    using (SQLiteCommand cmd = new SQLiteCommand(updateBalanceQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@TotalBalance", balance);
                        cmd.Parameters.AddWithValue("@PersonID", personID);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating person balance: " + ex.Message);
            }
        }

        private bool IsNullOrWhiteSpace(string value)
        {
            return string.IsNullOrEmpty(value) || value.Trim().Length == 0;
        }

        private void btnEssDelete_Click(object sender, EventArgs e)
        {
            if (dgrEssExpenseView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete?", "Delete data", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                return;
            }

            try
            {
                int selectedRowIndex = dgrEssExpenseView.SelectedRows[0].Index;
                int expenseID = Convert.ToInt32(dgrEssExpenseView.Rows[selectedRowIndex].Cells["ExpenseID"].Value);

                // Delete from database
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM Expense WHERE ExpenseID = @ExpenseID", connection))
                    {
                        cmd.Parameters.AddWithValue("@ExpenseID", expenseID);
                        cmd.ExecuteNonQuery();
                    }
                }

                // Remove from dataset
                DataRow row = dataSet.Tables["Expense"].Rows.Find(expenseID);
                if (row != null)
                {
                    row.Delete();
                }

                // Refresh DataGridView
                LoadExpense();
                UpdateCount();
                ClearForm();
                MessageBox.Show("Expense data deleted successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting data: " + ex.Message);
            }
        }

        private void UpdateCount()
        {
            if (dataSet != null && dataSet.Tables.Contains("Expense"))
            {
                txtEssCount.Text = dataSet.Tables["Expense"].Rows.Count.ToString();
            }
            else
            {
                txtEssCount.Text = "0";
            }
        }


       

        private void ClearForm()
        {
            txtEssExpenseID.Clear();
            cmbEssPerson.SelectedIndex = -1;
            cmbEssCategory.SelectedIndex = -1;
            dtpEssDate.Value = DateTime.Now;
            txtEssAmount.Clear();
            dgrEssExpenseView.ClearSelection();
            txtEssBalance.Clear();
            UpdateCount();
        }

        private void btnEssClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btnEssClose_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to close this Window?", "Close Application", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void dgrEssExpenseView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgrEssExpenseView.Rows[e.RowIndex];
                txtEssExpenseID.Text = row.Cells["ExpenseID"].Value.ToString();
                cmbEssPerson.Text = row.Cells["PersonName"].Value.ToString();
                cmbEssCategory.Text = row.Cells["CategoryName"].Value.ToString();
                txtEssAmount.Text = row.Cells["Amount"].Value.ToString();
                dtpEssDate.Value = Convert.ToDateTime(row.Cells["Date"].Value);

                int personID = (int)cmbEssPerson.SelectedValue;
                CalculateBalance(personID);
            }
        }

        private void CalculateBalance(int personID)
        {
            using (var connection = new SQLiteConnection(strCS))
            {
                connection.Open();
                string receiptQuery = "SELECT SUM(Amount) FROM Receipt WHERE PersonID = @PersonID";
                string expenseQuery = "SELECT SUM(Amount) FROM Expense WHERE PersonID = @PersonID";

                using (var cmd = new SQLiteCommand(receiptQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@PersonID", personID);
                    var receiptTotal = cmd.ExecuteScalar();
                    double totalReceipts = receiptTotal != DBNull.Value ? Convert.ToDouble(receiptTotal) : 0;

                    cmd.CommandText = expenseQuery;
                    var expenseTotal = cmd.ExecuteScalar();
                    double totalExpenses = expenseTotal != DBNull.Value ? Convert.ToDouble(expenseTotal) : 0;

                    double balance = totalReceipts - totalExpenses;
                    txtEssBalance.Text = balance.ToString();
                }
            }
        }


        private void btnEssExpenseSearch_Click(object sender, EventArgs e)
        {
            ExpenseSearch expenseSearch = new ExpenseSearch();
            expenseSearch.Show();
            this.Hide();
        }

        private void cmbEssPerson_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        private void btnEssExcel_Click(object sender, EventArgs e)
        {
            string strFileName = @"E:\Current Files\PettyCash\PettyCashApplication\PettyCashApp\bin\Debug\ExpensePageExportTemplate.xlsx";
            ExcelExport eport = new ExcelExport(ExcelAppType.MicrosoftExcel, false);
            eport.OpenWorkbook(strFileName);
            eport.SetVisible(false);
            DataTable dt = (DataTable)dgrEssExpenseView.DataSource;
            if (dt != null && dt.Rows.Count > 0)
            {
                int Rowspos = 2;
                foreach (DataRow row in dt.Select())
                {
                    eport.SetCellContent(Rowspos, 1, row[0]);
                    eport.SetCellContent(Rowspos, 2, row[1]);
                    eport.SetCellContent(Rowspos, 3, row[2]);
                    eport.SetCellContent(Rowspos, 4, row[3]);
                    eport.SetCellContent(Rowspos, 5, row[4]);
                    Rowspos++;
                }
            }
            eport.SetVisible(true);
            MessageBox.Show("Export Success");
        }

        private void txtEssCount_TextChanged(object sender, EventArgs e)
        {

        }

        private void ExpensePage_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadPersons();
            LoadCategories();
            InitializeAdapter();
            dgrEssExpenseView.ClearSelection();
            ClearForm();
            dgrEssExpenseView.SelectionChanged += grdEssExpenseView_SelectionChanged;


            // Set up the ComboBox
            //cmbEssPerson.DataSource = personData;
            cmbEssPerson.DisplayMember = "PersonName";
            cmbEssPerson.ValueMember = "PersonID";
        }


        private void grdEssExpenseView_SelectionChanged(object sender, EventArgs e)
        {
            if (dgrEssExpenseView.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgrEssExpenseView.SelectedRows[0];
        
                // Make sure these column names match the ones in the DataGridView
                txtEssExpenseID.Text = row.Cells["ExpenseID"].Value.ToString();
                cmbEssPerson.Text = row.Cells["PersonName"].Value.ToString();
                cmbEssCategory.Text = row.Cells["CategoryName"].Value.ToString();
                txtEssAmount.Text = row.Cells["Amount"].Value.ToString();
                dtpEssDate.Value = Convert.ToDateTime(row.Cells["Date"].Value);

                // Assuming cmbEssPerson is correctly populated and has a selected value
                if (cmbEssPerson.SelectedValue != null)
                {
                    int personID = (int)cmbEssPerson.SelectedValue;
                    CalculateBalance(personID);
                }
            }
        }


        private void InitializeAdapter()
        {
            adapter = new SQLiteDataAdapter("SELECT * FROM Expense", strCS);
            SQLiteCommandBuilder builder = new SQLiteCommandBuilder(adapter);

            adapter.InsertCommand = builder.GetInsertCommand();
            adapter.UpdateCommand = builder.GetUpdateCommand();
            adapter.DeleteCommand = builder.GetDeleteCommand();
        }

        private void LoadData()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                string query = "SELECT e.ExpenseID, p.Name AS PersonName, c.CategoryName AS CategoryName, e.Amount, e.Date " +
                               "FROM Expense e " +
                               "JOIN Person p ON e.PersonID = p.PersonID " +
                               "JOIN Category c ON e.CategoryID = c.CategoryID";

                adapter = new SQLiteDataAdapter(query, connection);

                dataSet = new DataSet();
                adapter.Fill(dataSet, "Expense");
                dataSet.Tables["Expense"].PrimaryKey = new DataColumn[] { dataSet.Tables["Expense"].Columns["ExpenseID"] };
                UpdateCount();
                dgrEssExpenseView.DataSource = dataSet.Tables["Expense"];
                txtEssCount.Text = dataSet.Tables["Expense"].Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void InitializeEssBoundGridView()
        {
            dgrEssExpenseView.AutoGenerateColumns = false;
            dgrEssExpenseView.Columns.Clear();

            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ExpenseID",
                DataPropertyName = "ExpenseID",
                HeaderText = "Expense ID",
                ReadOnly = true
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PersonName",
                DataPropertyName = "PersonName",
                HeaderText = "Person Name"
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "CategoryName",
                DataPropertyName = "CategoryName",
                HeaderText = "Category Name"
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Amount",
                DataPropertyName = "Amount",
                HeaderText = "Amount"
            });
            dgrEssExpenseView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Date",
                DataPropertyName = "Date",
                HeaderText = "Date"
            });
        }

        private void LoadPersons()
        {
            try
            {
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    string query = "SELECT PersonID, Name FROM Person";
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        cmbEssPerson.DataSource = dt;
                        cmbEssPerson.DisplayMember = "Name";
                        cmbEssPerson.ValueMember = "PersonID";
                        cmbEssPerson.SelectedIndex = -1;
                    }
                }
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading persons: " + ex.Message);
            }
        }

        private void LoadCategories()
        {
            try
            {
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    string query = "SELECT CategoryID, CategoryName FROM Category";
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        cmbEssCategory.DataSource = dt;
                        cmbEssCategory.DisplayMember = "CategoryName";
                        cmbEssCategory.ValueMember = "CategoryID";
                        cmbEssCategory.SelectedIndex = -1;
                    }
                }
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading categories: " + ex.Message);
            }
        }

        private void dgrEssExpenseView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


    }


}
