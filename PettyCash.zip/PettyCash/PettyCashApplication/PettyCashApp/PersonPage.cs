﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;

namespace PettyCashApplication
{
    public partial class Person : Form
    {
        private DataSet dataSet;
        private SQLiteDataAdapter dataAdapter;
        private SQLiteConnection connection;
        string strPath = "PettyCash.db";
        private string strCS = @"URI=file:" + Application.StartupPath + "\\PettyCash.db";

        public Person()
        {
            InitializeComponent();
            txtEssCount.ReadOnly = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove maximize and minimize buttons, only close button should be visible
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            UpdateCount();
            dgrEssExpenseManager.ClearSelection();
            ClearForm();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateDatabase();
            InitializeDataGridView();
            dgrEssExpenseManager.ClearSelection();
            LoadData();
            ClearForm();
            //dgrEssExpenseManager.SelectionChanged += dgrEssExpenseManager_SelectionChanged;
            UpdateCount();
        }

        private void CreateDatabase()
        {
            try
            {
                if (!System.IO.File.Exists(strPath))
                {
                    SQLiteConnection.CreateFile(strPath);
                    using (var varSqlite = new SQLiteConnection(@"Data Source=" + strPath))
                    {
                        varSqlite.Open();

                        string strSqlPerson = "CREATE TABLE Person (PersonID INTEGER PRIMARY KEY, Name VARCHAR(50), TotalBalance INTEGER DEFAULT 0)";
                        SQLiteCommand commandPerson = new SQLiteCommand(strSqlPerson, varSqlite);
                        commandPerson.ExecuteNonQuery();

                        string strSqlCategory = "CREATE TABLE Category (CategoryID INTEGER PRIMARY KEY, CategoryName VARCHAR(30))";
                        SQLiteCommand commandCategory = new SQLiteCommand(strSqlCategory, varSqlite);
                        commandCategory.ExecuteNonQuery();

                        string strSqlReceipt = @"CREATE TABLE Receipt (
                                                ReceiptID INTEGER PRIMARY KEY,
                                                PersonID INTEGER,
                                                Date DATE,
                                                Amount INTEGER,
                                                FOREIGN KEY (PersonID) REFERENCES Person(PersonID))";
                        SQLiteCommand commandReceipt = new SQLiteCommand(strSqlReceipt, varSqlite);
                        commandReceipt.ExecuteNonQuery();

                        string strSqlExpense = @"CREATE TABLE Expense (
                                                ExpenseID INTEGER PRIMARY KEY,
                                                PersonID INTEGER,
                                                CategoryID INTEGER,
                                                Amount INTEGER,
                                                FOREIGN KEY (PersonID) REFERENCES Person(PersonID),
                                                FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID))";
                        SQLiteCommand commandExpense = new SQLiteCommand(strSqlExpense, varSqlite);
                        commandExpense.ExecuteNonQuery();

                        string strCreateTriggers = @"
                            CREATE TRIGGER after_receipt_insert
                            AFTER INSERT ON Receipt
                            FOR EACH ROW
                            BEGIN
                                UPDATE Person
                                SET TotalBalance = TotalBalance + NEW.Amount
                                WHERE PersonID = NEW.PersonID;
                            END;

                            CREATE TRIGGER after_receipt_delete
                            AFTER DELETE ON Receipt
                            FOR EACH ROW
                            BEGIN
                                UPDATE Person
                                SET TotalBalance = TotalBalance - OLD.Amount
                                WHERE PersonID = OLD.PersonID;
                            END;

                            CREATE TRIGGER after_expense_insert
                            AFTER INSERT ON Expense
                            FOR EACH ROW
                            BEGIN
                                UPDATE Person
                                SET TotalBalance = TotalBalance - NEW.Amount
                                WHERE PersonID = NEW.PersonID;
                            END;

                            CREATE TRIGGER after_expense_delete
                            AFTER DELETE ON Expense
                            FOR EACH ROW
                            BEGIN
                                UPDATE Person
                                SET TotalBalance = TotalBalance + OLD.Amount
                                WHERE PersonID = OLD.PersonID;
                            END;";

                        SQLiteCommand commandTriggers = new SQLiteCommand(strCreateTriggers, varSqlite);
                        commandTriggers.ExecuteNonQuery();

                        MessageBox.Show("Database and tables created successfully.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating database: " + ex.Message);
            }
        }

        private void LoadData()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                dataAdapter = new SQLiteDataAdapter("SELECT * FROM Person", connection);

                SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(dataAdapter);

                dataSet = new DataSet();
                dataAdapter.Fill(dataSet, "Person");
                dataSet.Tables["Person"].PrimaryKey = new DataColumn[] { dataSet.Tables["Person"].Columns["PersonID"] };

                dgrEssExpenseManager.DataSource = dataSet.Tables["Person"];
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            } 
        }

        private void InitializeDataGridView()
        {
            dgrEssExpenseManager.AutoGenerateColumns = false;
            dgrEssExpenseManager.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgrEssExpenseManager.Columns.Clear();

            DataGridViewTextBoxColumn PersonIDColumn = new DataGridViewTextBoxColumn
            {
                Name = "PersonID",
                HeaderText = "Person ID",
                DataPropertyName = "PersonID"
            };
            dgrEssExpenseManager.Columns.Add(PersonIDColumn);

            DataGridViewTextBoxColumn nameColumn = new DataGridViewTextBoxColumn
            {
                Name = "Name",
                HeaderText = "Name",
                DataPropertyName = "Name"
            };
            dgrEssExpenseManager.Columns.Add(nameColumn);

            DataGridViewTextBoxColumn totalBalanceColumn = new DataGridViewTextBoxColumn
            {
                Name = "TotalBalance",
                HeaderText = "Total Balance",
                DataPropertyName = "TotalBalance"
            };
            dgrEssExpenseManager.Columns.Add(totalBalanceColumn);
        }


        private void dgrEssExpenseManager_SelectionChanged(object sender, EventArgs e)
        {
            if (dgrEssExpenseManager.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgrEssExpenseManager.SelectedRows[0];
                txtEssExpenseMasterID.Text = row.Cells["PersonID"].Value.ToString();
                txtEssExpenseMasterName.Text = row.Cells["Name"].Value.ToString();
            }
        }



        private void btnEssSave_Click(object sender, EventArgs e)
        {
            // Check for individual empty fields and display appropriate message
            if (IsNullOrWhiteSpace(txtEssExpenseMasterID.Text))
            {
                MessageBox.Show("Please enter Person ID.");
                return;
            }

            if (IsNullOrWhiteSpace(txtEssExpenseMasterName.Text))
            {
                MessageBox.Show("Please enter Name.");
                return;
            }

            if (dgrEssExpenseManager.SelectedRows.Count > 0)
            {
                UpdateData();
            }
            else
            {
                InsertData();
            }
        }


        private bool CheckIfExistsID(string value)
        {
            bool exists = false;
            string query = "SELECT COUNT(1) FROM Person WHERE PersonID = @value";

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(strCS))
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@value", value);
                        exists = Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking ID existence: " + ex.Message);
            }

            return exists;
        }


        private bool CheckIfExistsName(string value)
        {
            bool exists = false;
            string query = "SELECT COUNT(1) FROM Person WHERE LOWER(Name) = LOWER(@value)";

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(strCS))
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@value", value);
                        exists = Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking Name existence: " + ex.Message);
            }

            return exists;
        }

        private void InsertData()
        {
            try
            {
                string PersonID = txtEssExpenseMasterID.Text.Trim();
                string strPersonName = txtEssExpenseMasterName.Text.Trim().ToLower();

                // Check if Person ID already exists
                if (CheckIfExistsID(PersonID))
                {
                    MessageBox.Show("The ID already exists. Please enter a different ID.");
                    return;
                }

                // Check if Person Name already exists
                if (CheckIfExistsName(strPersonName))
                {
                    MessageBox.Show("The name already exists. Please enter a different name.");
                    return;
                }

                DataRow newRow = dataSet.Tables["Person"].NewRow();
                newRow["PersonID"] = Convert.ToInt32(PersonID);
                newRow["Name"] = txtEssExpenseMasterName.Text;
                newRow["TotalBalance"] = 0; // Set default TotalBalance to 0
                dataSet.Tables["Person"].Rows.Add(newRow);
                dataAdapter.Update(dataSet, "Person");

                LoadData(); // Refresh DataGridView
                UpdateCount();
                ClearForm();
                MessageBox.Show("Person inserted successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting person: " + ex.Message);
            }
        }

        private void UpdateData()
        {
            try
            {
                if (dgrEssExpenseManager.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a row to update.");
                    return;
                }

                int intSelectedRowIndex = dgrEssExpenseManager.SelectedRows[0].Index;
                DataRow row = dataSet.Tables["Person"].Rows.Find(Convert.ToInt32(dgrEssExpenseManager.Rows[intSelectedRowIndex].Cells["PersonID"].Value));

                string newName = txtEssExpenseMasterName.Text.Trim().ToLower();

                if (CheckIfExistsName(newName) && row["Name"].ToString().ToLower() != newName)
                {
                    MessageBox.Show("The name already exists in another record. Please enter a different name.");
                    return;
                }

                row["Name"] = txtEssExpenseMasterName.Text;
                dataAdapter.Update(dataSet, "Person");

                LoadData(); // Refresh DataGridView
                UpdateCount();
                ClearForm();
                MessageBox.Show("Person updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating person: " + ex.Message);
            }
        }


        private bool IsNullOrWhiteSpace(string value)
        {
            return string.IsNullOrEmpty(value) || value.Trim().Length == 0;
        }

        private void btnEssClear_Click(object sender, EventArgs e)
        {
            txtEssExpenseMasterID.Clear();
            txtEssExpenseMasterName.Clear();
            dgrEssExpenseManager.ClearSelection();
        }

        private void btnEssClose_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to close the application?", "Close Application", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        /*
        private void btnEssNext_Click(object sender, EventArgs e)
        {
            if (dgrEssExpenseManager.SelectedRows.Count > 0)
            {
                var selectedRow = dgrEssExpenseManager.SelectedRows[0];
                string selectedPersonID = selectedRow.Cells["PersonID"].Value.ToString();
                string selectedstrPersonName = selectedRow.Cells["Name"].Value.ToString();

                DialogResult dialogResult = MessageBox.Show(
                    string.Format("You have selected: \n \n ID: {0} \n Name: {1} \n \n You sure want to continue?", selectedPersonID, selectedstrPersonName),
                    "Confirmation",
                    MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    ReceiptPage receiptPage = new ReceiptPage();
                    receiptPage.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Please select a row first.");
            }
        }
        */

        private void ClearForm()
        {
            txtEssExpenseMasterID.Clear();
            txtEssExpenseMasterName.Clear();
            dgrEssExpenseManager.ClearSelection();
        }

        private void txtEssExpenseMasterID_TextChanged(object sender, EventArgs e)
        {
        }



        private void btnEssDelete_Click_1(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dgrEssExpenseManager.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            // Ask for confirmation
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete?", "Delete data", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Delete();
            }
        }

        private void Delete()
        {
            try
            {
                int intSelectedRowIndex = dgrEssExpenseManager.SelectedRows[0].Index;
                int PersonID = Convert.ToInt32(dgrEssExpenseManager.Rows[intSelectedRowIndex].Cells["PersonID"].Value);

                DataRow row = dataSet.Tables["Person"].Rows.Find(PersonID);
                if (row != null)
                {
                    row.Delete();
                    // Use the appropriate command builder to ensure the delete command is generated
                    SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(dataAdapter);

                    // Apply changes to the database
                    dataAdapter.Update(dataSet, "Person");

                    LoadData(); // Refresh DataGridView
                    UpdateCount();
                    ClearForm();
                    MessageBox.Show("Person deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Selected row not found in the dataset.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting person: " + ex.Message);
            }
        }


        private void dgrEssExpenseManager_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgrEssExpenseManager.Rows[e.RowIndex];
                txtEssExpenseMasterID.Text = row.Cells["PersonID"].Value.ToString();
                txtEssExpenseMasterName.Text = row.Cells["Name"].Value.ToString();
            }
        }

        private void dgrEssExpenseManager_SelectionChanged_1(object sender, EventArgs e)
        {
            if (dgrEssExpenseManager.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgrEssExpenseManager.SelectedRows[0];
                txtEssExpenseMasterID.Text = row.Cells["PersonID"].Value.ToString();
                txtEssExpenseMasterName.Text = row.Cells["Name"].Value.ToString();
            }
        }

        private void UpdateCount()
        {
            if (dataSet != null && dataSet.Tables.Contains("Person"))
            {
                txtEssCount.Text = dataSet.Tables["Person"].Rows.Count.ToString();
            }
            else
            {
                txtEssCount.Text = "0";
            }
        }
    }
}