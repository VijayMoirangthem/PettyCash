﻿namespace PettyCashApp
{
    partial class ReceiptSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReceiptSearch));
            this.cmbEssPerson = new eSurvey.Controls.ESSComboBox();
            this.lblEssName = new eSurvey.Controls.ESSLabel();
            this.btnEssFilter = new eSurvey.Controls.ESSButton();
            this.btnEssExport = new eSurvey.Controls.ESSButton();
            this.lblEssDate = new eSurvey.Controls.ESSLabel();
            this.dtpEssEnd = new eSurvey.Controls.ESSDateTimePicker();
            this.dgrEssReceiptSearch = new eSurvey.Controls.ESSGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEssPerson = new eSurvey.Controls.ESSButton();
            this.btnEssDetails = new eSurvey.Controls.ESSButton();
            this.btnEssCategory = new eSurvey.Controls.ESSButton();
            this.txtEssCount = new eSurvey.Controls.ESSTextBox();
            this.lblEssCount = new eSurvey.Controls.ESSLabel();
            this.dtpEssStart = new eSurvey.Controls.ESSDateTimePicker();
            this.lblEssTo = new eSurvey.Controls.ESSLabel();
            this.btnEssClear = new eSurvey.Controls.ESSButton();
            this.btnEssClose = new eSurvey.Controls.ESSButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssReceiptSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbEssPerson
            // 
            this.cmbEssPerson.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEssPerson.FormattingEnabled = true;
            this.cmbEssPerson.Location = new System.Drawing.Point(90, 15);
            this.cmbEssPerson.Name = "cmbEssPerson";
            this.cmbEssPerson.Size = new System.Drawing.Size(188, 30);
            this.cmbEssPerson.TabIndex = 1;
            this.cmbEssPerson.SelectedIndexChanged += new System.EventHandler(this.cmbEssPerson_SelectedIndexChanged);
            // 
            // lblEssName
            // 
            this.lblEssName.AutoSize = true;
            this.lblEssName.Location = new System.Drawing.Point(25, 23);
            this.lblEssName.Name = "lblEssName";
            this.lblEssName.Size = new System.Drawing.Size(59, 23);
            this.lblEssName.TabIndex = 2;
            this.lblEssName.Text = "Name:";
            // 
            // btnEssFilter
            // 
            this.btnEssFilter.Location = new System.Drawing.Point(236, 54);
            this.btnEssFilter.Name = "btnEssFilter";
            this.btnEssFilter.Size = new System.Drawing.Size(184, 33);
            this.btnEssFilter.TabIndex = 3;
            this.btnEssFilter.Text = "Filter";
            this.btnEssFilter.UseVisualStyleBackColor = true;
            this.btnEssFilter.Click += new System.EventHandler(this.btnEssFilter_Click);
            // 
            // btnEssExport
            // 
            this.btnEssExport.Location = new System.Drawing.Point(445, 54);
            this.btnEssExport.Name = "btnEssExport";
            this.btnEssExport.Size = new System.Drawing.Size(184, 33);
            this.btnEssExport.TabIndex = 4;
            this.btnEssExport.Text = "Export";
            this.btnEssExport.UseVisualStyleBackColor = true;
            this.btnEssExport.Click += new System.EventHandler(this.btnEssExport_Click);
            // 
            // lblEssDate
            // 
            this.lblEssDate.AutoSize = true;
            this.lblEssDate.Location = new System.Drawing.Point(302, 23);
            this.lblEssDate.Name = "lblEssDate";
            this.lblEssDate.Size = new System.Drawing.Size(51, 23);
            this.lblEssDate.TabIndex = 5;
            this.lblEssDate.Text = "Date:";
            // 
            // dtpEssEnd
            // 
            this.dtpEssEnd.Location = new System.Drawing.Point(652, 19);
            this.dtpEssEnd.Name = "dtpEssEnd";
            this.dtpEssEnd.Size = new System.Drawing.Size(184, 26);
            this.dtpEssEnd.TabIndex = 6;
            // 
            // dgrEssReceiptSearch
            // 
            this.dgrEssReceiptSearch.AllowUserToAddRows = false;
            this.dgrEssReceiptSearch.AllowUserToDeleteRows = false;
            this.dgrEssReceiptSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrEssReceiptSearch.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgrEssReceiptSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrEssReceiptSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrEssReceiptSearch.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgrEssReceiptSearch.Location = new System.Drawing.Point(29, 105);
            this.dgrEssReceiptSearch.MaxRows = 1;
            this.dgrEssReceiptSearch.Name = "dgrEssReceiptSearch";
            this.dgrEssReceiptSearch.ReadOnly = true;
            this.dgrEssReceiptSearch.RowTemplate.Height = 24;
            this.dgrEssReceiptSearch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrEssReceiptSearch.Size = new System.Drawing.Size(807, 265);
            this.dgrEssReceiptSearch.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // btnEssPerson
            // 
            this.btnEssPerson.Location = new System.Drawing.Point(29, 381);
            this.btnEssPerson.Name = "btnEssPerson";
            this.btnEssPerson.Size = new System.Drawing.Size(90, 33);
            this.btnEssPerson.TabIndex = 8;
            this.btnEssPerson.Text = "Person";
            this.btnEssPerson.UseVisualStyleBackColor = true;
            this.btnEssPerson.Click += new System.EventHandler(this.btnEssPerson_Click);
            // 
            // btnEssDetails
            // 
            this.btnEssDetails.Location = new System.Drawing.Point(125, 381);
            this.btnEssDetails.Name = "btnEssDetails";
            this.btnEssDetails.Size = new System.Drawing.Size(90, 33);
            this.btnEssDetails.TabIndex = 9;
            this.btnEssDetails.Text = "Receipt";
            this.btnEssDetails.UseVisualStyleBackColor = true;
            this.btnEssDetails.Click += new System.EventHandler(this.btnEssDetails_Click);
            // 
            // btnEssCategory
            // 
            this.btnEssCategory.Location = new System.Drawing.Point(221, 381);
            this.btnEssCategory.Name = "btnEssCategory";
            this.btnEssCategory.Size = new System.Drawing.Size(90, 33);
            this.btnEssCategory.TabIndex = 10;
            this.btnEssCategory.Text = "Category";
            this.btnEssCategory.UseVisualStyleBackColor = true;
            this.btnEssCategory.Click += new System.EventHandler(this.btnEssCategory_Click);
            // 
            // txtEssCount
            // 
            this.txtEssCount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Location = new System.Drawing.Point(775, 381);
            this.txtEssCount.Name = "txtEssCount";
            this.txtEssCount.Size = new System.Drawing.Size(61, 26);
            this.txtEssCount.TabIndex = 11;
            // 
            // lblEssCount
            // 
            this.lblEssCount.AutoSize = true;
            this.lblEssCount.Location = new System.Drawing.Point(709, 384);
            this.lblEssCount.Name = "lblEssCount";
            this.lblEssCount.Size = new System.Drawing.Size(60, 23);
            this.lblEssCount.TabIndex = 12;
            this.lblEssCount.Text = "Count:";
            // 
            // dtpEssStart
            // 
            this.dtpEssStart.Location = new System.Drawing.Point(370, 20);
            this.dtpEssStart.Name = "dtpEssStart";
            this.dtpEssStart.Size = new System.Drawing.Size(184, 26);
            this.dtpEssStart.TabIndex = 13;
            this.dtpEssStart.ValueChanged += new System.EventHandler(this.dtpEssStart_ValueChanged);
            // 
            // lblEssTo
            // 
            this.lblEssTo.AutoSize = true;
            this.lblEssTo.Location = new System.Drawing.Point(586, 23);
            this.lblEssTo.Name = "lblEssTo";
            this.lblEssTo.Size = new System.Drawing.Size(27, 23);
            this.lblEssTo.TabIndex = 14;
            this.lblEssTo.Text = "To";
            // 
            // btnEssClear
            // 
            this.btnEssClear.Location = new System.Drawing.Point(29, 54);
            this.btnEssClear.Name = "btnEssClear";
            this.btnEssClear.Size = new System.Drawing.Size(184, 33);
            this.btnEssClear.TabIndex = 15;
            this.btnEssClear.Text = "New";
            this.btnEssClear.UseVisualStyleBackColor = true;
            this.btnEssClear.Click += new System.EventHandler(this.btnEssClear_Click);
            // 
            // btnEssClose
            // 
            this.btnEssClose.Location = new System.Drawing.Point(652, 54);
            this.btnEssClose.Name = "btnEssClose";
            this.btnEssClose.Size = new System.Drawing.Size(184, 33);
            this.btnEssClose.TabIndex = 16;
            this.btnEssClose.Text = "Close";
            this.btnEssClose.UseVisualStyleBackColor = true;
            this.btnEssClose.Click += new System.EventHandler(this.btnEssClose_Click);
            // 
            // ReceiptSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 426);
            this.Controls.Add(this.btnEssClose);
            this.Controls.Add(this.btnEssClear);
            this.Controls.Add(this.lblEssTo);
            this.Controls.Add(this.dtpEssStart);
            this.Controls.Add(this.lblEssCount);
            this.Controls.Add(this.txtEssCount);
            this.Controls.Add(this.btnEssCategory);
            this.Controls.Add(this.btnEssDetails);
            this.Controls.Add(this.btnEssPerson);
            this.Controls.Add(this.dgrEssReceiptSearch);
            this.Controls.Add(this.dtpEssEnd);
            this.Controls.Add(this.lblEssDate);
            this.Controls.Add(this.btnEssExport);
            this.Controls.Add(this.btnEssFilter);
            this.Controls.Add(this.lblEssName);
            this.Controls.Add(this.cmbEssPerson);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReceiptSearch";
            this.Text = "Receipt Search";
            this.Load += new System.EventHandler(this.ReceiptSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrEssReceiptSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private eSurvey.Controls.ESSComboBox cmbEssPerson;
        private eSurvey.Controls.ESSLabel lblEssName;
        private eSurvey.Controls.ESSButton btnEssFilter;
        private eSurvey.Controls.ESSButton btnEssExport;
        private eSurvey.Controls.ESSLabel lblEssDate;
        private eSurvey.Controls.ESSDateTimePicker dtpEssEnd;
        private eSurvey.Controls.ESSGridView dgrEssReceiptSearch;
        private eSurvey.Controls.ESSButton btnEssPerson;
        private eSurvey.Controls.ESSButton btnEssDetails;
        private eSurvey.Controls.ESSButton btnEssCategory;
        private eSurvey.Controls.ESSTextBox txtEssCount;
        private eSurvey.Controls.ESSLabel lblEssCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private eSurvey.Controls.ESSDateTimePicker dtpEssStart;
        private eSurvey.Controls.ESSLabel lblEssTo;
        private eSurvey.Controls.ESSButton btnEssClear;
        private eSurvey.Controls.ESSButton btnEssClose;
    }
}