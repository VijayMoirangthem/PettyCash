﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;



namespace ESSExcelExport
{
    internal enum ExcelAppType
    {
        MicrosoftExcel,
        OpenOffice
    }

    internal class ExcelExport : IDisposable
    {

        private object application;
        private object appManager;
        private object workbook;
        private object sheet;
        const int xlTemplate = 17;
        private ExcelAppType excelAppType;

        public object objExcelApp;//Changes Commented Excel
        public object objWorkBook;//Changes Commented Excel
        public object objWorkSheet;//Changes Commented Excel
        public bool blnObjectCreated;
        private short intOfficeType;
        public object objExcelOpenApp;//Changes Commented Excel

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                application = null;
                appManager = null;
                workbook = null;
                sheet = null;
            }
        }

        /// <summary>
        /// Creates new instance of excel workbook
        /// </summary>
        /// <param name="appType">Indicate whether it is Microsoft Excel or Open Office</param>
        public ExcelExport(ExcelAppType appType) : this(appType, true) { }

        /// <summary>
        /// Creates new instance of excel workbook
        /// </summary>
        /// <param name="appType">Indicate whether it is Microsoft Excel or Open Office</param>
        /// <param name="createWorkBook">Indicate whether to create a new workbook</param>
        public ExcelExport(ExcelAppType appType, bool createWorkBook)
        {
            excelAppType = appType;

            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                Type excelType = Type.GetTypeFromProgID("Excel.Application");
                application = Activator.CreateInstance(excelType);
                application.GetType().InvokeMember("Visible", BindingFlags.SetProperty, null, application, new object[] { true });
            }
            else
            {
                Type excelType = Type.GetTypeFromProgID("com.sun.star.ServiceManager");
                appManager = Activator.CreateInstance(excelType);
                application = appManager.GetType().InvokeMember("createInstance", BindingFlags.InvokeMethod, null, appManager, new object[] { "com.sun.star.frame.Desktop" });
            }

            if (createWorkBook)
            {
                NewWorkBook();
            }
        }

        /// <summary>
        /// Creates new workbook
        /// </summary>

        public void CreateExcelApp(ref short intOffice)
        {
            try
            {
                intOfficeType = intOffice;
                if (intOfficeType == 0)
                {
                    objExcelApp = System.Activator.CreateInstance(System.Type.GetTypeFromProgID("EXCEL.APPLICATION"));
                    //objExcelApp.Visible = True
                }
                else
                {
                    objExcelOpenApp = System.Activator.CreateInstance(System.Type.GetTypeFromProgID("com.sun.star.ServiceManager"));
                    //UPGRADE_WARNING: Couldn't resolve default property of object objExcelOpenApp.createInstance. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    //objExcelApp = objExcelOpenApp.createInstance("com.sun.star.frame.Desktop");
                    //'        Set objWorkBook = objExcelApp.loadComponentFromURL(ConvertToUrl("New"), "_blank", 0, arg())
                    //'        Set objWorkSheet = objWorkBook.CurrentController.ActiveSheet 'objWorkBook.Sheets(0)

                    //objExcelApp.Visible = True
                }
                blnObjectCreated = true;
                return;
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message, modThisApp.glbPrdCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);

                // goto KillErr;
                blnObjectCreated = false;
                //UPGRADE_NOTE: Object objExcelOpenApp may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
                objExcelOpenApp = null;
                //UPGRADE_NOTE: Object objExcelApp may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
                objExcelApp = null;
            }
            //KillErr:
            //    blnObjectCreated = false;
            //    //UPGRADE_NOTE: Object objExcelOpenApp may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
            //    objExcelOpenApp = null;
            //    //UPGRADE_NOTE: Object objExcelApp may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
            //    objExcelApp = null;
        }

        public void NewWorkBook()
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object workbooks = application.GetType().InvokeMember("Workbooks", BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Add", BindingFlags.InvokeMethod, null, workbooks, null);
            }
            else
            {
                object[] args = new object[2];
                args[0] = InitiateAPropertyValue();
                args[1] = InitiateAPropertyValue();
                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { "private:factory/scalc", "_blank", 0, args });
            }
        }

        /// <summary>
        /// Set excel workbook visibility
        /// </summary>
        /// <param name="value">True to make it visible, False otherwise</param>
        public void SetVisible(bool value)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                application.GetType().InvokeMember("Visible", BindingFlags.SetProperty, null, application, new object[] { value });
            }
            else
            {
                if (workbook != null)
                {
                    object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                    object frame = controler.GetType().InvokeMember("Frame", BindingFlags.GetProperty, null, controler, null);
                    object container = frame.GetType().InvokeMember("ContainerWindow", BindingFlags.GetProperty, null, frame, null);
                    container.GetType().InvokeMember("SetVisible", BindingFlags.InvokeMethod, null, container, new object[] { value });
                }
            }
        }

        /// <summary>
        /// Open the given workbook file
        /// </summary>
        /// <param name="path">Excel file path</param>
        public void OpenWorkbook(string path)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = path;
                object workbooks = application.GetType().InvokeMember("Workbooks", BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Open", BindingFlags.InvokeMethod, null, workbooks, args);

            }
            else
            {
                object[] args = new object[2];
                args[0] = InitiateAPropertyValue();
                args[1] = InitiateAPropertyValue();
                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { PathConverter(path), "_blank", 0, args });
            }
            sheet = GetActiveSheet();
        }

        /// <summary>
        /// Open excel template file
        /// </summary>
        /// <param name="path">Template file path</param>
        public void OpenWorkBookTemplate(string path)
        {
            OpenWorkBookTemplate(path, true);
        }

        /// <summary>
        /// Open excel template file
        /// </summary>
        /// <param name="path">Template file path</param>
        /// <param name="isLocal">Indicate whether template file is in local directory</param>
        public void OpenWorkBookTemplate(string path, bool isLocal)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = new object();
                if (isLocal)
                {
                    args[0] = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar + path;
                }
                else
                {
                    args[0] = path;
                }
                object workbooks = application.GetType().InvokeMember("Workbooks", BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Open", BindingFlags.InvokeMethod, null, workbooks, args);
            }
            else
            {
                object[] args = new object[2];
                args[0] = MakePropertyValue("Hidden", "true");
                args[1] = MakePropertyValue("AsTemplate", "true");
                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { PathConverter(path), "_blank", 0, args });
            }
            sheet = GetActiveSheet();
        }

        /// <summary>
        /// Saves excel workbook file
        /// </summary>
        /// <param name="strFileName">Source file name</param>
        public void SaveWorkbook(string strFileName)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[2];
                args[0] = strFileName;
                args[1] = xlTemplate;
                object objWorkBook = application.GetType().InvokeMember("ActiveWorkbook", BindingFlags.GetProperty, null, application, null);
                objWorkBook.GetType().InvokeMember("SaveAs", BindingFlags.GetProperty, null, objWorkBook, args);
            }
        }

        /// <summary>
        /// Saves excel  file
        /// </summary>
        /// <param name="strFileName">Source file name</param>
        public void SaveExcel(string strFileName)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = strFileName;
                //args[1] = xlTemplate;
                object objWorkBook = application.GetType().InvokeMember("ActiveWorkbook", BindingFlags.GetProperty, null, application, null);
                objWorkBook.GetType().InvokeMember("SaveAs", BindingFlags.GetProperty, null, objWorkBook, args);
            }
        }

        private string PathConverter(string file)
        {
            file = file.Replace(@"\", "/");
            file = file.Replace(" ", "%20");
            return "file:///" + file;
        }

        public void SaveAs(string path)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = path;
                workbook.GetType().InvokeMember("SaveAs", BindingFlags.InvokeMethod, null, workbook, args);
            }
            else
            {
                // Add corresponding logic for other applications
            }
        }

        private Object InitiateAPropertyValue()
        {
            return appManager.GetType().InvokeMember("Bridge_GetStruct", BindingFlags.InvokeMethod, null, appManager, new object[] { "com.sun.star.beans.PropertyValue" });
        }

        private Object SetPropertyValues(Object popertyvalue, string name, string value)
        {
            popertyvalue.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, popertyvalue, new object[] { value });
            return popertyvalue;
        }

        private Object MakePropertyValue(string name, string value)
        {
            return SetPropertyValues(InitiateAPropertyValue(), name, value);
        }

        /// <summary>
        /// Get cell value in the active sheet
        /// </summary>
        /// <param name="col">Column index</param>
        /// <param name="row">Row index</param>
        /// <returns>Cell value</returns>
        //public object GetValue(long col, long row)
        public object GetCellContent(int row, int col)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                return cell.GetType().InvokeMember("Value", BindingFlags.GetProperty, null, cell, null);
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                return cell.GetType().InvokeMember("String", BindingFlags.GetProperty, null, cell, null);
            }
        }

        /// <summary>
        /// Selects a cell value in the active sheet
        /// </summary>
        /// <param name="col">Column index</param>
        /// <param name="row">Row index</param>
        /// <returns>Selected value</returns>
        public object SelectCell(long col, long row)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                return cell.GetType().InvokeMember("Select", BindingFlags.InvokeMethod, null, cell, null);
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                return cell.GetType().InvokeMember("String", BindingFlags.GetProperty, null, cell, null);
            }
        }

        /// <summary>
        /// Exports data table value to the active sheet from the specified start index
        /// </summary>
        /// <param name="data">Data table holding values</param>
        /// <param name="startIndex">Start index</param>
        public void Export(DataTable data, int startIndex)
        {
            object sheet = GetActiveSheet();
            for (int row = 0; row < data.Rows.Count; row++)
            {
                DataRow rowData = data.Rows[row];
                for (int column = 0; column < data.Columns.Count; column++)
                {
                    SetValue(sheet, column + 1, (row + startIndex), rowData[column]);
                }
            }
        }

        /// <summary>
        /// Exports data stored in excel sheet instance.
        /// </summary>
        /// <param name="sheet">Excel sheet instance holding data to be exported</param>
        public void Export(ExcelSheet sheet)
        {
            SetExcelSheetName(sheet.Name);
            ExportColumns(sheet.Columns);
            ExportData(sheet.Data);
        }

        public void SetExcelSheetName(string name)
        {
            object sheet = GetActiveSheet();
            sheet.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, sheet, new object[] { name });
        }

        public object GetActiveSheet()
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
                return application.GetType().InvokeMember("ActiveSheet", BindingFlags.GetProperty, null, application, null);
            object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
            return controler.GetType().InvokeMember("ActiveSheet", BindingFlags.GetProperty, null, controler, null);
        }

        /// <summary>
        /// Gets active sheet name
        /// </summary>
        /// <returns></returns>
        public object GetSheetName()
        {
            object sheet = GetActiveSheet();
            return sheet.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, sheet, null);
        }

        /// <summary>
        /// Selects worksheet at the given index
        /// </summary>
        /// <param name="index">Worksheet index</param>
        public void SelectWorkSheetByNumber(int index)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Select", BindingFlags.GetProperty, null, sheet, null);
            }
            else
            {
                object[] args = new object[1];
                args[0] = index - 1;
                var sheets = workbook.GetType().InvokeMember("getSheets", BindingFlags.InvokeMethod, null, workbook, null);
                sheet = workbook.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, sheets, args);
                object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                object[] args1 = new object[1];
                args1[0] = sheet;
                controler.GetType().InvokeMember("ActiveSheet", BindingFlags.SetProperty, null, controler, args1);
            }
        }
        public string GetSheetNameByNumber(int index)
        {
            string sht = string.Empty;
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, args);
                object shtVal = sheet.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, sheet, null);
                //  sht = TypeConverter.ConvertToString(shtVal);
            }
            return sht;
        }
        public void SelectWorkSheet(int index)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Select", BindingFlags.GetProperty, null, sheet, null);
            }
            else
            {
                object[] args = new object[1];
                args[0] = index - 1;
                var sheets = workbook.GetType().InvokeMember("getSheets", BindingFlags.InvokeMethod, null, workbook, null);
                sheet = workbook.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, sheets, args);
                object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                object[] args1 = new object[1];
                args1[0] = sheet;
                controler.GetType().InvokeMember("ActiveSheet", BindingFlags.SetProperty, null, controler, args1);
            }
        }

        /// <summary>
        /// Remove worksheet at the given index
        /// </summary>
        /// <param name="index">Worksheet index</param>
        public void DeleteWorkSheet(int index)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Delete", BindingFlags.GetProperty, null, sheet, null);
            }

        }

        /// <summary>
        /// Set number format for the given range
        /// </summary>
        /// <param name="strRange">Range in the active worksheet</param>
        /// <param name="strFormat">Number format to be applied</param>
        public void SetRangeNumberFormat(string strRange, string strFormat)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                objRange.GetType().InvokeMember("NumberFormat", BindingFlags.SetProperty, null, objRange, new object[] { strFormat });
            }
        }

        /// <summary>
        /// Sets border to the given cell
        /// </summary>
        /// <param name="strRange">Range indicator</param>
        /// <param name="blnLeft">Indidates whether left cell border to be set</param>
        /// <param name="blnRight">Indidates whether right cell border to be set</param>
        /// <param name="blnTop">Indidates whether top cell border to be set</param>
        /// <param name="blnBottom">Indidates whether bottom cell border to be set</param>
        /// <param name="blnHorizontal">Indidates whether horizontal line style to be set</param>
        /// <param name="blnVertical">Indidates whether vertical line style to be set</param>
        public void SetMarkBorder(string strRange, bool blnLeft, bool blnRight, bool blnTop, bool blnBottom, bool blnHorizontal, bool blnVertical)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                object border;
                if (blnLeft)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 7 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnRight)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 10 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }

                if (blnTop)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 8 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnBottom)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 9 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }

                if (blnHorizontal)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 11 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnVertical)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 12 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
            }
        }

        /// <summary>
        /// Sets background color of the given range
        /// </summary>
        /// <param name="strRange">Range indicator</param>
        /// <param name="intColorIndex">Color index</param>
        public void SetRangeBackColor(string strRange, int intColorIndex)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                var interior = objRange.GetType().InvokeMember("Interior", BindingFlags.GetProperty, null, objRange, null);
                interior.GetType().InvokeMember("ColorIndex", BindingFlags.SetProperty, null, interior, new object[] { intColorIndex });
            }
        }

        /// <summary>
        /// Hides columns from the given index in the active worksheet
        /// </summary>
        /// <param name="StartCol">Start column index</param>
        public void HideColumnsFrom(int StartCol)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                var sheet = GetActiveSheet();
                var strStartCol = GetExcelColumnName(StartCol);
                int icolsCount;
                var columns = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, null);
                var colcount = sheet.GetType().InvokeMember("Count", BindingFlags.GetProperty, null, columns, null);
                icolsCount = (int)colcount;
                var strEndCol = GetExcelColumnName(icolsCount);
                var selection = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { strStartCol + ":" + strEndCol });
                var entirecol = selection.GetType().InvokeMember("EntireColumn", BindingFlags.GetProperty, null, selection, null);
                entirecol.GetType().InvokeMember("Hidden", BindingFlags.SetProperty, null, entirecol, new object[] { true });
            }
        }

        private string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            while (dividend > 0)
            {
                var modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo) + columnName;
                dividend = (dividend - modulo) / 26;
            }
            return columnName;
        }

        /// <summary>
        /// Updates column width of active worksheet
        /// </summary>
        /// <param name="columns">List of values to update worksheet column width.</param>
        public void ColumnWidths(List<int> columns)
        {
            object sheet = GetActiveSheet();
            for (int i = 0; i < columns.Count; i++)
            {
                SetColWidth(sheet, i + 1, columns[i]);
            }
        }

        /// <summary>
        /// Creates column in the worksheet
        /// </summary>
        /// <param name="columns">List of column names</param>
        public void ExportColumns(List<string> columns)
        {
            object sheet = GetActiveSheet();
            for (int i = 0; i < columns.Count; i++)
            {
                string column = columns[i];
                SetValue(sheet, i + 1, 1, column);
            }
        }

        /// <summary>
        /// Exports data to excel worksheet
        /// </summary>
        /// <param name="data">Set row row values to be exported</param>
        public void ExportData(List<List<string>> data)
        {
            object sheet = GetActiveSheet();
            for (int row = 0; row < data.Count; row++)
            {
                List<string> rowData = data[row];
                for (int column = 0; column < rowData.Count; column++)
                {
                    SetValue(sheet, column + 1, (row + 2), rowData[column]);
                }
            }
        }

        public void SetValue(object sheet, int col, int row, object value)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                cell.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, cell, new[] { value });
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                cell.GetType().InvokeMember("String", BindingFlags.SetProperty, null, cell, new[] { value });
            }
        }

        /// <summary>
        /// Set value to a cell in active worksheet
        /// </summary>
        /// <param name="col">Column index</param>
        /// <param name="row">Row index</param>
        /// <param name="value">Value to be assigned</param>
        public void SetCellContent(int row, int col, object value)
        {
            object sheet = GetActiveSheet();
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                cell.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, cell, new[] { value });
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                cell.GetType().InvokeMember("String", BindingFlags.SetProperty, null, cell, new[] { value });
            }
        }

        public void SetCellContent(int row, int col, object value, bool IsBold)
        {
            object sheet = GetActiveSheet();
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                cell.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, cell, new[] { value });
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                cell.GetType().InvokeMember("String", BindingFlags.SetProperty, null, cell, new[] { value });
            }
        }

        /// <summary>
        /// Set column width of an excel sheet
        /// </summary>
        /// <param name="sheet">Worksheet with the given column</param>
        /// <param name="index">Column index</param>
        /// <param name="length">Column width</param>
        public void SetColWidth(object sheet, int index, int length)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object Colm = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { index, Missing.Value });

                Colm.GetType().InvokeMember("ColumnWidth", BindingFlags.SetProperty, null, Colm, new object[] { length });
            }
            else
            {
                object Colms = sheet.GetType().InvokeMember("getColumns", BindingFlags.InvokeMethod, null, sheet, null);
                object Colm = Colms.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, Colms, new object[] { index - 1 });

                object propValue = new object();
                propValue = MakePropertyValue("Width", Convert.ToString(length * 10));
                Colm.GetType().InvokeMember("setPropertyValue", BindingFlags.InvokeMethod, null, Colm, new object[] { "Width", Convert.ToInt32(length * 100 * 2.5) });
            }
        }

        /// <summary>
        /// Set width of column in the active sheet
        /// </summary>
        /// <param name="index">Column index</param>
        /// <param name="length">Column with</param>
        public void SetColumnWidth(int index, double length)
        {
            object sheet = GetActiveSheet();
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object Colm = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { index, Missing.Value });

                Colm.GetType().InvokeMember("ColumnWidth", BindingFlags.SetProperty, null, Colm, new object[] { length });
            }
            else
            {
                object Colms = sheet.GetType().InvokeMember("getColumns", BindingFlags.InvokeMethod, null, sheet, null);
                object Colm = Colms.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, Colms, new object[] { index - 1 });

                object propValue = new object();
                propValue = MakePropertyValue("Width", Convert.ToString(length * 10));
                Colm.GetType().InvokeMember("setPropertyValue", BindingFlags.InvokeMethod, null, Colm, new object[] { "Width", Convert.ToInt32(length * 100 * 2.5) });
            }
        }

        /// <summary>
        /// Close open workbook
        /// </summary>
        public void CloseWorkbook()
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                if (workbook != null)
                {
                    workbook.GetType().InvokeMember("Close", BindingFlags.InvokeMethod, null, workbook, new object[] { false });
                    Marshal.ReleaseComObject(workbook);
                    workbook = null;
                    sheet = null;
                }
            }
            else
            {
                if (workbook != null)
                {
                    workbook.GetType().InvokeMember("Dispose", BindingFlags.InvokeMethod, null, workbook, null);
                    Marshal.ReleaseComObject(workbook);
                    workbook = null;
                    sheet = null;
                }
            }
        }

        /// <summary>
        /// Close excel instance
        /// </summary>
        public void CloseExcel()
        {

            try
            {

                if (workbook != null)
                    CloseWorkbook();


                if (excelAppType == ExcelAppType.MicrosoftExcel)
                {
                    if (workbook == null)
                    {

                        Type excelApp = excelAppType.GetType();
                        excelApp.InvokeMember("Quit", BindingFlags.InvokeMethod, null, excelAppType, null);

                    }
                    application = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                else
                {
                    application.GetType().InvokeMember("terminate", BindingFlags.InvokeMethod, null, application, null);
                }
            }
            catch (Exception ex)
            {
                Marshal.ReleaseComObject(application);
            }


        }

        public void CellsMearge(string strRange1, string strRange2)
        {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1, strRange2 });
            objRange.GetType().InvokeMember("MergeCells", BindingFlags.SetProperty, null, objRange, new object[] { true });
        }

        public void SetVerticalAlignment(string strRange1, int Alignment)
        {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("VerticalAlignment", BindingFlags.SetProperty, null, objRange, new object[] { Alignment });
        }


        public void SetHorisontalAlignment(string strRange1, int Alignment)
        {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("HorizontalAlignment", BindingFlags.SetProperty, null, objRange, new object[] { Alignment });
        }

        public void SetRowHeight(string strRange1, double Height)
        {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("RowHeight", BindingFlags.SetProperty, null, objRange, new object[] { Height });
        }

        public void SetWrapText(string strRange1)
        {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("WrapText", BindingFlags.SetProperty, null, objRange, new object[] { true });
        }

        public void SetOrientation(int orientation)
        {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("PageSetup", BindingFlags.GetProperty, null, sheet, null);
            objRange.GetType().InvokeMember("Orientation", BindingFlags.SetProperty, null, objRange, new object[] { orientation });
        }

        public void SetFont(string strRange1, string strRange2, object font)
        {
            System.Drawing.Font newFont = (System.Drawing.Font)(font);
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new Object[] { strRange1, strRange2 });
            var objFont = objRange.GetType().InvokeMember("Font", BindingFlags.GetProperty, null, objRange, null);

            objRange.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, objFont, new Object[] { newFont.Name });
            objRange.GetType().InvokeMember("Size", BindingFlags.SetProperty, null, objFont, new Object[] { newFont.Size });
            objRange.GetType().InvokeMember("FontStyle", BindingFlags.SetProperty, null, objFont, new Object[] { newFont.Style });
        }
        public void SetRangeBold(string range)
        {

            if (intOfficeType == 0)
            {
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new Object[] { range });
                var objFont = objRange.GetType().InvokeMember("Font", BindingFlags.GetProperty, null, objRange, null);
                objRange.GetType().InvokeMember("Bold", BindingFlags.SetProperty, null, objFont, new Object[] { true });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellRangebyName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellRangebyName(strRange).CharWeight = 150;
                object objRange = sheet.GetType().InvokeMember("getCellRangebyName", BindingFlags.InvokeMethod, null, sheet, new Object[] { range });
                objRange.GetType().InvokeMember("CharWeight", BindingFlags.SetProperty, null, objRange, new Object[] { 150 });
            }
        }
        public void SetCellShrinkToFit(int intRow, int intCol, bool blnFit)
        {
            if (intOfficeType == 0)
            {
                object sheet = GetActiveSheet();
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { intRow, intCol });
                cell.GetType().InvokeMember("ShrinkToFit", BindingFlags.SetProperty, null, cell, new object[] { blnFit });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellByPosition. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellByPosition(intCol - 1, intRow - 1).ShrinkToFit = blnFit;
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { intCol - 1, intRow - 1 });
                cell.GetType().InvokeMember("ShrinkToFit", BindingFlags.SetProperty, null, cell, new object[] { blnFit });
            }
        }
        public void SetRangeGreyBackColor(string range)
        {
            if (intOfficeType == 0)
            {
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new Object[] { range });
                var objInterior = objRange.GetType().InvokeMember("Interior", BindingFlags.GetProperty, null, objRange, null);
                objRange.GetType().InvokeMember("ColorIndex", BindingFlags.SetProperty, null, objInterior, new Object[] { 15 });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellRangebyName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellRangebyName(strRange).CellBackColor = Microsoft.VisualBasic.Information.RGB(192, 192, 192);
                object objRange = sheet.GetType().InvokeMember("getCellRangebyName", BindingFlags.InvokeMethod, null, sheet, new Object[] { range });
                //  objRange.GetType().InvokeMember("CellBackColor", BindingFlags.SetProperty, null, objRange, new Object[] { Microsoft.VisualBasic.Information.RGB(192, 192, 192) });
            }
        }
        public void SetRangeAlignCentre(object range)
        {
            object oCursor = null;
            if (intOfficeType == 0)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new Object[] { range });
                objRange.GetType().InvokeMember("HorizontalAlignment", BindingFlags.SetProperty, null, objRange, new Object[] { 7 });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellRangebyName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellRangebyName(strRange).HoriJustify = 2;
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellRangebyName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.createCursorByRange. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oCursor = objWorkSheet.createCursorByRange(objWorkSheet.getCellRangebyName(strRange));
                //UPGRADE_WARNING: Couldn't resolve default property of object oCursor.Merge. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oCursor.Merge(true);//Changes Commented
            }
        }
        public void InsertPageHeader(string strText, bool blnDate)
        {
            object oCursor = null;
            object oDateTime = null;
            object oPStyle = null;
            object oStyles = null;
            object oPageNumber = null;
            object oHeader = null;
            if (intOfficeType == 0)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("PageSetup", BindingFlags.GetProperty, null, sheet, null);
                objRange.GetType().InvokeMember("LeftHeader", BindingFlags.SetProperty, null, objRange, new object[] { strText });
                if (blnDate)
                {
                    objRange.GetType().InvokeMember("RightHeader", BindingFlags.SetProperty, null, objRange, new object[] { "Date: &D" });
                }
            }
            else
            {
                //oDoc = ThisComponent
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.getStyleFamilies. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oStyles = objWorkBook.getStyleFamilies().getByName("PageStyles");
                //UPGRADE_WARNING: Couldn't resolve default property of object oStyles.getByName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oPStyle = oStyles.getByName("Default");
                //Changes Commented
                //// Get page number and page count objects.
                ////Set oPageNumber = objWorkBook.createInstance("com.sun.star.text.TextField.PageNumber")
                ////oPageCount = objExcelApp.createInstance("com.sun.star.text.TextField.PageCount")
                ////UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.createInstance. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oDateTime = objWorkBook.createInstance("com.sun.star.text.TextField.DateTime");

                //// Edit header
                ////UPGRADE_WARNING: Couldn't resolve default property of object oPStyle.RightPageHeaderContent. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oHeader = oPStyle.RightPageHeaderContent;
                ////UPGRADE_WARNING: Couldn't resolve default property of object oHeader.getLeftText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oHeader.getLeftText.setString(strText);
                ////UPGRADE_WARNING: Couldn't resolve default property of object oHeader.getCenterText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oHeader.getCenterText.setString("");
                ////oHeader.getCenterText().setString ("ABC Company, Inc.")
                ////UPGRADE_WARNING: Couldn't resolve default property of object oHeader.getRightText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oCursor = oHeader.getRightText().createTextCursor();
                //if (blnDate)
                //{
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oHeader.getRightText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oHeader.getRightText().insertString(oCursor, "Date:", false);
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oHeader.getRightText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oHeader.getRightText().insertTextContent(oCursor, oDateTime, true);
                //}
                ////UPGRADE_WARNING: Couldn't resolve default property of object oPStyle.RightPageHeaderContent. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                ////UPGRADE_WARNING: Couldn't resolve default property of object oHeader. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oPStyle.RightPageHeaderContent = oHeader;
                //Changes Commented
            }
        }
        public void InsertPageFooter(string strText, bool blnPageNo)
        {
            object oCursor = null;

            object oPageCount = null;
            object oPageNumber = null;
            object oStyles = null;
            object oPStyle = null;
            object oDateTime = null;
            object oFooter = null;
            if (intOfficeType == 0)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("PageSetup", BindingFlags.GetProperty, null, sheet, null);
                objRange.GetType().InvokeMember("LeftFooter", BindingFlags.SetProperty, null, objRange, new object[] { strText });
                if (blnPageNo)
                {
                    objRange.GetType().InvokeMember("RightFooter", BindingFlags.SetProperty, null, objRange, new object[] { "&P of &N" });
                }
            }
            else
            {
                //oDoc = ThisComponent
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.getStyleFamilies. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oStyles = objWorkBook.getStyleFamilies().getByName("PageStyles");
                //Changes Commented
                //UPGRADE_WARNING: Couldn't resolve default property of object oStyles.getByName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oPStyle = oStyles.getByName("Default");

                //// Get page number and page count objects.
                ////UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.createInstance. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oPageNumber = objWorkBook.createInstance("com.sun.star.text.TextField.PageNumber");
                ////UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.createInstance. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oPageCount = objWorkBook.createInstance("com.sun.star.text.TextField.PageCount");
                ////Set oDateTime = objWorkBook.createInstance("com.sun.star.text.TextField.DateTime")

                ////UPGRADE_WARNING: Couldn't resolve default property of object oPStyle.RightPageFooterContent. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oFooter = oPStyle.RightPageFooterContent;
                ////UPGRADE_WARNING: Couldn't resolve default property of object oFooter.getLeftText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oFooter.getLeftText.setString(strText);
                ////UPGRADE_WARNING: Couldn't resolve default property of object oFooter.getCenterText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oFooter.getCenterText.setString("");

                ////oFooter.getRightText.setString ("Page ")
                //if (blnPageNo)
                //{
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oFooter.getRightText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oCursor = oFooter.getRightText().createTextCursor();
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oCursor.gotoEnd. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oCursor.gotoEnd(false);
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oFooter.getRightText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oFooter.getRightText().insertTextContent(oCursor, oPageNumber, true);
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oCursor.gotoEnd. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oCursor.gotoEnd(false);
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oCursor.setString. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oCursor.setString(" of ");
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oCursor.gotoEnd. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oCursor.gotoEnd(false);
                //    //UPGRADE_WARNING: Couldn't resolve default property of object oFooter.getRightText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //    oFooter.getRightText().insertTextContent(oCursor, oPageCount, true);
                //}
                ////UPGRADE_WARNING: Couldn't resolve default property of object oPStyle.RightPageFooterContent. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                ////UPGRADE_WARNING: Couldn't resolve default property of object oFooter. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //oPStyle.RightPageFooterContent = oFooter;
                //Changes Commented
            }
        }
        public object DeleteRow(int intRow)
        {
            if (intOfficeType == 0)
            {
                object sheet = GetActiveSheet();
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { intRow, 1 });
                var entireRow = cell.GetType().InvokeMember("EntireRow", BindingFlags.GetProperty, null, cell, null);
                entireRow.GetType().InvokeMember("Delete", BindingFlags.InvokeMethod, null, entireRow, null);
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.GetRows. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.GetRows.removeByIndex(intRow - 1, 1);
                //objWorkSheet.getCellRangeByName(strRange).Rows.IsStartOfNewPage = True
            }
            return null;
        }
        public void SetCellGreyBackColor(int intRow, int intCol)
        {
            if (intOfficeType == 0)
            {
                var cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new Object[] { intRow, intCol });
                var objInterior = cell.GetType().InvokeMember("Interior", BindingFlags.GetProperty, null, cell, null);
                cell.GetType().InvokeMember("ColorIndex", BindingFlags.SetProperty, null, objInterior, new Object[] { 15 });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellByPosition. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellByPosition(intCol - 1, intRow - 1).CellBackColor = Microsoft.VisualBasic.Information.RGB(192, 192, 192);
            }
        }
        public void SetCellNumberFormat(int intRow, int intCol, string strFormat)
        {
            short intNumFormat = 0;
            if (intOfficeType == 0)
            {
                var cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new Object[] { intRow, intCol });
                cell.GetType().InvokeMember("NumberFormat", BindingFlags.SetProperty, null, cell, new Object[] { strFormat });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.CharLocale. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.getNumberFormats. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //intNumFormat = objWorkBook.getNumberFormats.queryKey(strFormat, objWorkBook.CharLocale, false);
                if (intNumFormat == -1) //Not yet defined
                {
                    //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.CharLocale. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.getNumberFormats. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    //intNumFormat = objWorkBook.getNumberFormats.AddNew(strFormat, objWorkBook.CharLocale);
                }
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellByPosition. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellByPosition(intCol - 1, intRow - 1).NumberFormat = intNumFormat;
            }
        }
        public void SetCellAlign(int intRow, int intCol, short intFormat_1L_2C_3R)
        {
            if (intOfficeType == 0)
            {
                if (intFormat_1L_2C_3R == 3)
                {
                    var cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new Object[] { intRow, intCol });
                    cell.GetType().InvokeMember("HorizontalAlignment", BindingFlags.SetProperty, null, cell, new Object[] { -4152 });
                }
                else if (intFormat_1L_2C_3R == 2)
                {
                    var cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new Object[] { intRow, intCol });
                    cell.GetType().InvokeMember("HorizontalAlignment", BindingFlags.SetProperty, null, cell, new Object[] { -4108 });
                }
                else
                {
                    var cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new Object[] { intRow, intCol });
                    cell.GetType().InvokeMember("HorizontalAlignment", BindingFlags.SetProperty, null, cell, new Object[] { -4131 });
                }
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellByPosition. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellByPosition(intCol - 1, intRow - 1).HoriJustify = intFormat_1L_2C_3R;
            }
        }
        public void SetRangeShrinkToFit(string strRange, bool blnFit)
        {
            if (intOfficeType == 0)
            {
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new Object[] { strRange });
                objRange.GetType().InvokeMember("ShrinkToFit", BindingFlags.SetProperty, null, objRange, new object[] { blnFit });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellRangebyName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellRangebyName(strRange).ShrinkToFit = blnFit;
            }
        }
        public void MarkBorder(string strRange, bool blnLeft, bool blnRight, bool blnTop, bool blnBottom, bool blnHorizontal, bool blnVertical)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                object border;
                if (blnLeft)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 7 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnRight)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 10 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }

                if (blnTop)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 8 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnBottom)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 9 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }

                if (blnHorizontal)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 11 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnVertical)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 12 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
            }
        }
        public void SetRangeBold(object strRange)
        {
            if (intOfficeType == 0)
            {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new Object[] { strRange });
                var objFont = objRange.GetType().InvokeMember("Font", BindingFlags.GetProperty, null, objRange, null);
                objRange.GetType().InvokeMember("Bold", BindingFlags.SetProperty, null, objFont, new Object[] { true });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellRangebyName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellRangebyName(strRange).CharWeight = 150;
            }
        }
        public void insertPageBreak(string strRange)
        {
            if (intOfficeType == 0)
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.Range. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.HPageBreaks. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.HPageBreaks.Add(Before:objWorkSheet.Range(strRange));//Changes Commented
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                object pageBreak = sheet.GetType().InvokeMember("HPageBreaks", BindingFlags.GetProperty, null, sheet, null);
                pageBreak.GetType().InvokeMember("Add", BindingFlags.InvokeMethod, null, pageBreak, new object[] { objRange });
                pageBreak = null;
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellRangebyName. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellRangebyName(strRange).Rows.IsStartOfNewPage = true;
                //objWorkSheet.getCellRangeByName(strRange).Rows.IsStartOfNewPage = True
            }

        }
        public void SetCellBold(int intRow, int intCol)
        {
            if (intOfficeType == 0)
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.Cells. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.Cells(intRow, intCol).Font.Bold = true;
                var cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new Object[] { intRow, intCol });
                var objFont = cell.GetType().InvokeMember("Font", BindingFlags.GetProperty, null, cell, null);
                cell.GetType().InvokeMember("Bold", BindingFlags.SetProperty, null, objFont, new Object[] { true });
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellByPosition. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellByPosition(intCol - 1, intRow - 1).CharWeight = 150;
            }
        }
        internal void SetCellValue(int p, string p_2)
        {
            throw new NotImplementedException();
        }

        public short GetSheetCount()
        {
            short tempGetSheetCount = 0;

            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object sheets = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, null);
                object count = sheets.GetType().InvokeMember("Count", BindingFlags.GetProperty, null, sheets, null);
                //  tempGetSheetCount = TypeConverter.ConvertToShort(count);
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.Sheets. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //tempGetSheetCount = (short)objWorkBook.Sheets.Count;
                //objWorkSheet.getCellRangeByName(strRange).Rows.IsStartOfNewPage = True
            }
            return tempGetSheetCount;
        }
        public void SelectWorkSheetByName(string strSheet)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = strSheet;
                sheet = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Select", BindingFlags.GetProperty, null, sheet, null);
            }
            else
            {
                //object[] args = new object[1];
                //args[0] = index - 1;
                //var sheets = workbook.GetType().InvokeMember("getSheets", BindingFlags.InvokeMethod, null, workbook, null);
                //sheet = workbook.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, sheets, args);
                //object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                //object[] args1 = new object[1];
                //args1[0] = sheet;
                //controler.GetType().InvokeMember("ActiveSheet", BindingFlags.SetProperty, null, controler, args1);
            }
        }
        public void InsertNewSheet(string strSheetName, bool blnBegining)
        {
            object oSheets = null;
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objExcelApp.ActiveWorkbook. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet = objExcelApp.ActiveWorkbook.Sheets.Add;
                object sheets = application.GetType().InvokeMember("sheets", BindingFlags.GetProperty, null, application, null);
                sheets = sheets.GetType().InvokeMember("Add", BindingFlags.InvokeMethod, null, sheets, null);
                SetExcelSheetName(strSheetName);
                SelectWorkSheetByName(strSheetName);
            }
            else
            {
                //Set oSheet = objWorkBook.createInstance("com.sun.star.sheet.Spreadsheet")
                //objWorkBook.Sheets.insertByName strSheetName, oSheet
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.Sheets. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkBook.Sheets.insertNewByName(strSheetName, (blnBegining ? 0 : objWorkBook.Sheets.Count));
                SelectWorkSheetByName(strSheetName);
            }
        }
        public void CopyWorkSheet(string strFromSheetName, object strToSheetName, short intPosition)
        {
            if (intOfficeType == 0)
            {
                SelectWorkSheetByName(strFromSheetName);
                var sheet = GetActiveSheet();
                object sheets = application.GetType().InvokeMember("sheets", BindingFlags.GetProperty, null, application, null);
                object newSheet = sheet.GetType().InvokeMember("Copy", BindingFlags.GetProperty, null, sheet, new object[] { sheet });

                //Set objWorkSheet = objExcelApp.Worksheets.Item(strSheetName)
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.Sheets. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkBook.Sheets(strFromSheetName).Copy(After:objWorkBook.Sheets(intPosition));//Changes Commented
            }
            else
            {
                //objWorkBook.CurrentController.ActiveSheet = objWorkBook.Sheets.getByName(strSheetName)

                //Set objWorkSheet = objWorkBook.CurrentController.ActiveSheet
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkBook.Sheets. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkBook.Sheets.copyByName(strFromSheetName, strToSheetName, intPosition);
            }
        }
        public void SetCellFontName(int intRow, int intCol, string strFontName)
        {
            //Deepa: Only copied from older excel class. functionality needs to be tested and updated
            if (intOfficeType == 0)
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.Cells. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.Cells(intRow, intCol).Font.Name = strFontName;
            }
            else
            {
                //UPGRADE_WARNING: Couldn't resolve default property of object objWorkSheet.getCellByPosition. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                //objWorkSheet.getCellByPosition(intCol - 1, intRow - 1).CharFontName = strFontName;
            }

        }
    }

    internal class ExcelSheet
    {
        /// <summary>
        /// Excel sheet name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// List of columns
        /// </summary>
        public List<string> Columns { get; set; }
        /// <summary>
        /// Excel sheet data
        /// </summary>
        public List<List<string>> Data { get; set; }

        internal ExcelSheet()
        {
            Columns = new List<string>();
            Data = new List<List<string>>();
        }

    }

}
