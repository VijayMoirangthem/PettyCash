﻿namespace PettyCashApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.personToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.personFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiptFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiptToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblEssTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.personToolStripMenuItem,
            this.receiptToolStripMenuItem,
            this.categoryToolStripMenuItem,
            this.expenseToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(835, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // personToolStripMenuItem
            // 
            this.personToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.personFormToolStripMenuItem});
            this.personToolStripMenuItem.Name = "personToolStripMenuItem";
            this.personToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.personToolStripMenuItem.Text = "Person";
            this.personToolStripMenuItem.Click += new System.EventHandler(this.personToolStripMenuItem_Click);
            // 
            // personFormToolStripMenuItem
            // 
            this.personFormToolStripMenuItem.Name = "personFormToolStripMenuItem";
            this.personFormToolStripMenuItem.Size = new System.Drawing.Size(159, 24);
            this.personFormToolStripMenuItem.Text = "Person Form";
            this.personFormToolStripMenuItem.Click += new System.EventHandler(this.personFormToolStripMenuItem_Click);
            // 
            // receiptToolStripMenuItem
            // 
            this.receiptToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.receiptFormToolStripMenuItem});
            this.receiptToolStripMenuItem.Name = "receiptToolStripMenuItem";
            this.receiptToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.receiptToolStripMenuItem.Text = "Receipt";
            // 
            // receiptFormToolStripMenuItem
            // 
            this.receiptFormToolStripMenuItem.Name = "receiptFormToolStripMenuItem";
            this.receiptFormToolStripMenuItem.Size = new System.Drawing.Size(166, 24);
            this.receiptFormToolStripMenuItem.Text = "Receipt Form";
            this.receiptFormToolStripMenuItem.Click += new System.EventHandler(this.receiptFormToolStripMenuItem_Click);
            // 
            // categoryToolStripMenuItem
            // 
            this.categoryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.categoryFormToolStripMenuItem});
            this.categoryToolStripMenuItem.Name = "categoryToolStripMenuItem";
            this.categoryToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.categoryToolStripMenuItem.Text = "Category";
            // 
            // categoryFormToolStripMenuItem
            // 
            this.categoryFormToolStripMenuItem.Name = "categoryFormToolStripMenuItem";
            this.categoryFormToolStripMenuItem.Size = new System.Drawing.Size(176, 24);
            this.categoryFormToolStripMenuItem.Text = "Category Form";
            this.categoryFormToolStripMenuItem.Click += new System.EventHandler(this.categoryFormToolStripMenuItem_Click);
            // 
            // expenseToolStripMenuItem
            // 
            this.expenseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expenseFormToolStripMenuItem});
            this.expenseToolStripMenuItem.Name = "expenseToolStripMenuItem";
            this.expenseToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.expenseToolStripMenuItem.Text = "Expense";
            // 
            // expenseFormToolStripMenuItem
            // 
            this.expenseFormToolStripMenuItem.Name = "expenseFormToolStripMenuItem";
            this.expenseFormToolStripMenuItem.Size = new System.Drawing.Size(170, 24);
            this.expenseFormToolStripMenuItem.Text = "Expense Form";
            this.expenseFormToolStripMenuItem.Click += new System.EventHandler(this.expenseFormToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.receiptToolStripMenuItem1,
            this.expenseToolStripMenuItem1});
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.searchToolStripMenuItem.Text = "Search";
            // 
            // receiptToolStripMenuItem1
            // 
            this.receiptToolStripMenuItem1.Name = "receiptToolStripMenuItem1";
            this.receiptToolStripMenuItem1.Size = new System.Drawing.Size(180, 24);
            this.receiptToolStripMenuItem1.Text = "Receipt Search";
            this.receiptToolStripMenuItem1.Click += new System.EventHandler(this.receiptToolStripMenuItem1_Click);
            // 
            // expenseToolStripMenuItem1
            // 
            this.expenseToolStripMenuItem1.Name = "expenseToolStripMenuItem1";
            this.expenseToolStripMenuItem1.Size = new System.Drawing.Size(180, 24);
            this.expenseToolStripMenuItem1.Text = "Expense Search";
            this.expenseToolStripMenuItem1.Click += new System.EventHandler(this.expenseToolStripMenuItem1_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.exitToolStripMenuItem.Text = "Exit ";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // lblEssTitle
            // 
            this.lblEssTitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblEssTitle.AutoSize = true;
            this.lblEssTitle.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblEssTitle.Font = new System.Drawing.Font("Ink Free", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEssTitle.Location = new System.Drawing.Point(-70, 41);
            this.lblEssTitle.Name = "lblEssTitle";
            this.lblEssTitle.Size = new System.Drawing.Size(941, 75);
            this.lblEssTitle.TabIndex = 1;
            this.lblEssTitle.Text = "Welcome to Petty Cash Application  ";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Font = new System.Drawing.Font("Ink Free", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-289, 378);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1275, 75);
            this.label1.TabIndex = 3;
            this.label1.Text = "-Effortlessly Track Your Daily Employee Expenses";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(835, 462);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblEssTitle);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Petty Cash Application";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem personToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem personFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiptFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoryFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expenseFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiptToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem expenseToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label lblEssTitle;
        private System.Windows.Forms.Label label1;
    }
}

