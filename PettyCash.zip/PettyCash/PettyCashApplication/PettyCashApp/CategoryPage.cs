﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;
using ESSExcelExport;

namespace PettyCashApplication
{
    public partial class CategoryPage : Form
    {
        private DataSet dataSet;
        private SQLiteDataAdapter dataAdapter;
        private SQLiteConnection connection;
        private string strCS = @"URI=file:" + Application.StartupPath + "\\PettyCash.db";

        public CategoryPage()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove maximize and minimize buttons, only close button should be visible
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            InitializeDataGridView();
            txtEssCount.ReadOnly = true;
        }

        private void CategoryPage_Load(object sender, EventArgs e)
        {
            LoadData();
            UpdateCount();
            ClearForm();
        }

        private void InitializeDataGridView()
        {
            dgrCategoryView.AutoGenerateColumns = false;
            dgrCategoryView.Columns.Clear();

            dgrCategoryView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "CategoryID",
                DataPropertyName = "CategoryID",
                HeaderText = "Category ID"
            });
            dgrCategoryView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "CategoryName",
                DataPropertyName = "CategoryName",
                HeaderText = "Category Name"
            });
        }

        private void LoadData()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                dataAdapter = new SQLiteDataAdapter("SELECT * FROM Category", connection);

                SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(dataAdapter);

                dataSet = new DataSet();
                dataAdapter.Fill(dataSet, "Category");
                dataSet.Tables["Category"].PrimaryKey = new DataColumn[] { dataSet.Tables["Category"].Columns["CategoryID"] };

                dgrCategoryView.DataSource = dataSet.Tables["Category"];
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void UpdateCount()
        {
            txtEssCount.Text = dataSet.Tables["Category"].Rows.Count.ToString();
        }

        private bool CheckIfExistsID(string value)
        {
            bool exists = false;
            string query = "SELECT COUNT(1) FROM Category WHERE CategoryID = @value";

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(strCS))
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@value", value);
                        exists = Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking ID existence: " + ex.Message);
            }

            return exists;
        }

        private bool CheckIfExistsName(string value)
        {
            bool exists = false;
            string query = "SELECT COUNT(1) FROM Category WHERE LOWER(CategoryName) = LOWER(@value)";

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(strCS))
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@value", value);
                        exists = Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking Name existence: " + ex.Message);
            }

            return exists;
        }

        private void btnEssSave_Click(object sender, EventArgs e)
        {
            if (IsNullOrWhiteSpace(txtEssCategoryID.Text))
            {
                MessageBox.Show("Please enter Category ID.");
                return;
            }

            if (IsNullOrWhiteSpace(txtEssCategoryName.Text))
            {
                MessageBox.Show("Please enter Category Name.");
                return;
            }

            if (dgrCategoryView.SelectedRows.Count > 0)
            {
                UpdateData();
            }
            else
            {
                InsertData();
            }
        }

        private bool IsNullOrWhiteSpace(string value)
        {
            return string.IsNullOrEmpty(value) || value.Trim().Length == 0;
        }

        private void InsertData()
        {
            try
            {
                string categoryID = txtEssCategoryID.Text.Trim();
                string categoryName = txtEssCategoryName.Text.Trim().ToLower();

                // Check if Person ID already exists
                if (CheckIfExistsID(categoryID))
                {
                    MessageBox.Show("The Category ID already exists. Please enter a different ID.");
                    return;
                }

                // Check if Person Name already exists
                if (CheckIfExistsName(categoryName))
                {
                    MessageBox.Show("The Category Name already exists. Please enter a different Name.");
                    return;
                }
            
                DataRow newRow = dataSet.Tables["Category"].NewRow();
                newRow["CategoryID"] = Convert.ToInt32(txtEssCategoryID.Text);
                newRow["CategoryName"] = txtEssCategoryName.Text;
                dataSet.Tables["Category"].Rows.Add(newRow);

                dataAdapter.Update(dataSet, "Category");

                LoadData();
                ClearForm();
                MessageBox.Show("Category added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting category: " + ex.Message);
            }
        }


        private void UpdateData()
        {
            try
            {
                if (dgrCategoryView.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a row to update.");
                    return;
                }

                int oldCategoryID = Convert.ToInt32(dgrCategoryView.SelectedRows[0].Cells["CategoryID"].Value);
                int newCategoryID = Convert.ToInt32(txtEssCategoryID.Text);
                int selectedRowIndex = dgrCategoryView.SelectedRows[0].Index;
                DataRow row = dataSet.Tables["Category"].Rows.Find(dgrCategoryView.Rows[selectedRowIndex].Cells["CategoryID"].Value);
                string newName = txtEssCategoryName.Text.Trim().ToLower();

                // Check if new name already exists in another row
                if (CheckIfExistsName(newName) && row["CategoryName"].ToString().ToLower() != newName)
                {
                    MessageBox.Show("The Category Name already exists.");
                    return;
                }

                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();

                    // Begin a transaction to ensure all updates are done atomically
                    using (SQLiteTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            if (oldCategoryID != newCategoryID)
                            {
                                // Update the CategoryID in the CATEGORY table
                                string updateCategoryQuery = "UPDATE CATEGORY SET CategoryID = @NewCategoryID, CategoryName = @CategoryName WHERE CategoryID = @OldCategoryID";
                                using (SQLiteCommand cmd = new SQLiteCommand(updateCategoryQuery, connection, transaction))
                                {
                                    cmd.Parameters.AddWithValue("@NewCategoryID", newCategoryID);
                                    cmd.Parameters.AddWithValue("@OldCategoryID", oldCategoryID);
                                    cmd.Parameters.AddWithValue("@CategoryName", txtEssCategoryName.Text);

                                    cmd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                // If CategoryID is not changed, just update the other fields
                                string updateQuery = "UPDATE CATEGORY SET CategoryName = @CategoryName WHERE CategoryID = @CategoryID";
                                using (SQLiteCommand cmd = new SQLiteCommand(updateQuery, connection, transaction))
                                {
                                    cmd.Parameters.AddWithValue("@CategoryID", oldCategoryID);
                                    cmd.Parameters.AddWithValue("@CategoryName", txtEssCategoryName.Text);

                                    cmd.ExecuteNonQuery();
                                }
                            }

                            // Commit the transaction
                            transaction.Commit();
                        }
                        catch (Exception)
                        {
                            // Rollback the transaction if any error occurs
                            transaction.Rollback();
                            throw;
                        }
                    }
                }

                // Refresh the dataset and DataGridView to reflect the updated data
                LoadData();
                ClearForm();
                MessageBox.Show("Category updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating category: " + ex.Message);
            }
        }


        private void btnEssDelete_Click(object sender, EventArgs e)
        {
            if (dgrCategoryView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete?", "Delete data", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Delete();
            }
        }

        private void Delete()
        {
            try
            {
                int selectedRowIndex = dgrCategoryView.SelectedRows[0].Index;
                int categoryID = Convert.ToInt32(dgrCategoryView.Rows[selectedRowIndex].Cells["CategoryID"].Value);

                DataRow row = dataSet.Tables["Category"].Rows.Find(categoryID);
                if (row != null)
                {
                    row.Delete();
                    //MessageBox.Show("Row marked for deletion.");

                    SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(dataAdapter);
                    dataAdapter.Update(dataSet, "Category");

                    LoadData();
                    ClearForm();
                    MessageBox.Show("Category deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Selected row not found in the dataset.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Category deleted successfully.");
            }
        }

        private void ClearForm()
        {
            txtEssCategoryID.Clear();
            txtEssCategoryName.Clear();
            dgrCategoryView.ClearSelection();
        }

        private void btnEssClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btnEssClose_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to close this Window?", "Close Application", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void dgrCategoryView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgrCategoryView.Rows[e.RowIndex];
                txtEssCategoryID.Text = row.Cells["CategoryID"].Value.ToString();
                txtEssCategoryName.Text = row.Cells["CategoryName"].Value.ToString();
            }
        }

        private void btnEssHome_Click(object sender, EventArgs e)
        {
            Person personPage = new Person();
            personPage.Show();
            this.Hide();
        }

        private void btnEssReceipt_Click(object sender, EventArgs e)
        {
            ReceiptPage receiptPage = new ReceiptPage();
            receiptPage.Show();
            this.Hide();
        }

        private void btnEssExport_Click(object sender, EventArgs e)
        {
            string strFileName = Application.StartupPath + @"\CategoryPageExportTemplate.xlsx";
            ExcelExport export = new ExcelExport(ExcelAppType.MicrosoftExcel, false);
            export.OpenWorkbook(strFileName);
            export.SetVisible(false);
            DataTable dt = (DataTable)dgrCategoryView.DataSource;
            if (dt != null && dt.Rows.Count > 0)
            {
                int Rowspos = 2;
                foreach (DataRow row in dt.Select())
                {
                    export.SetCellContent(Rowspos, 1, row["CategoryID"]);
                    export.SetCellContent(Rowspos, 2, row["CategoryName"]);
                    Rowspos++;
                }
            }
            export.SetVisible(true);
            MessageBox.Show("Export Success");
        }

        private void btnEssExpense_Click_1(object sender, EventArgs e)
        {
            ExpensePage expensePage = new ExpensePage();
            expensePage.Show();
            this.Hide();
        }

        private void dgrCategoryView_SelectionChanged(object sender, EventArgs e)
        {
            if (dgrCategoryView.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgrCategoryView.SelectedRows[0];
                txtEssCategoryID.Text = row.Cells["CategoryID"].Value.ToString();
                txtEssCategoryName.Text = row.Cells["CategoryName"].Value.ToString();
            }
        }

        private void lblEssCount_Click(object sender, EventArgs e)
        {

        }


    }
}
