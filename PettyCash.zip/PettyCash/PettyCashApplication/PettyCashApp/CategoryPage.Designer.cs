﻿namespace PettyCashApplication
{
    partial class CategoryPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CategoryPage));
            this.btnEssSave = new eSurvey.Controls.ESSButton();
            this.btnEssDelete = new eSurvey.Controls.ESSButton();
            this.btnEssClear = new eSurvey.Controls.ESSButton();
            this.btnEssClose = new eSurvey.Controls.ESSButton();
            this.lblEssCategoryID = new eSurvey.Controls.ESSLabel();
            this.txtEssCategoryID = new eSurvey.Controls.ESSTextBox();
            this.dgrCategoryView = new eSurvey.Controls.ESSGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEssReceipt = new eSurvey.Controls.ESSButton();
            this.txtEssCategoryName = new eSurvey.Controls.ESSTextBox();
            this.lblEssCategoryName = new eSurvey.Controls.ESSLabel();
            this.lblEssCount = new eSurvey.Controls.ESSLabel();
            this.txtEssCount = new eSurvey.Controls.ESSTextBox();
            this.btnEssExpense = new eSurvey.Controls.ESSButton();
            this.btnEssExport = new eSurvey.Controls.ESSButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgrCategoryView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnEssSave
            // 
            this.btnEssSave.Location = new System.Drawing.Point(189, 93);
            this.btnEssSave.Name = "btnEssSave";
            this.btnEssSave.Size = new System.Drawing.Size(93, 36);
            this.btnEssSave.TabIndex = 0;
            this.btnEssSave.Text = "Save";
            this.btnEssSave.UseVisualStyleBackColor = true;
            this.btnEssSave.Click += new System.EventHandler(this.btnEssSave_Click);
            // 
            // btnEssDelete
            // 
            this.btnEssDelete.Location = new System.Drawing.Point(336, 93);
            this.btnEssDelete.Name = "btnEssDelete";
            this.btnEssDelete.Size = new System.Drawing.Size(93, 36);
            this.btnEssDelete.TabIndex = 1;
            this.btnEssDelete.Text = "Delete";
            this.btnEssDelete.UseVisualStyleBackColor = true;
            this.btnEssDelete.Click += new System.EventHandler(this.btnEssDelete_Click);
            // 
            // btnEssClear
            // 
            this.btnEssClear.Location = new System.Drawing.Point(47, 93);
            this.btnEssClear.Name = "btnEssClear";
            this.btnEssClear.Size = new System.Drawing.Size(93, 36);
            this.btnEssClear.TabIndex = 2;
            this.btnEssClear.Text = "New";
            this.btnEssClear.UseVisualStyleBackColor = true;
            this.btnEssClear.Click += new System.EventHandler(this.btnEssClear_Click);
            // 
            // btnEssClose
            // 
            this.btnEssClose.Location = new System.Drawing.Point(624, 93);
            this.btnEssClose.Name = "btnEssClose";
            this.btnEssClose.Size = new System.Drawing.Size(93, 36);
            this.btnEssClose.TabIndex = 3;
            this.btnEssClose.Text = "Close";
            this.btnEssClose.UseVisualStyleBackColor = true;
            this.btnEssClose.Click += new System.EventHandler(this.btnEssClose_Click);
            // 
            // lblEssCategoryID
            // 
            this.lblEssCategoryID.AutoSize = true;
            this.lblEssCategoryID.Location = new System.Drawing.Point(42, 47);
            this.lblEssCategoryID.Name = "lblEssCategoryID";
            this.lblEssCategoryID.Size = new System.Drawing.Size(98, 23);
            this.lblEssCategoryID.TabIndex = 4;
            this.lblEssCategoryID.Text = "Category ID";
            // 
            // txtEssCategoryID
            // 
            this.txtEssCategoryID.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCategoryID.Location = new System.Drawing.Point(154, 44);
            this.txtEssCategoryID.Name = "txtEssCategoryID";
            this.txtEssCategoryID.Size = new System.Drawing.Size(177, 26);
            this.txtEssCategoryID.TabIndex = 5;
            this.txtEssCategoryID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCategoryID.Type = eSurvey.Controls.ESSTextBox.enumType.Number;
            // 
            // dgrCategoryView
            // 
            this.dgrCategoryView.AllowUserToAddRows = false;
            this.dgrCategoryView.AllowUserToDeleteRows = false;
            this.dgrCategoryView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrCategoryView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgrCategoryView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrCategoryView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrCategoryView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgrCategoryView.Location = new System.Drawing.Point(46, 151);
            this.dgrCategoryView.MaxRows = 1;
            this.dgrCategoryView.Name = "dgrCategoryView";
            this.dgrCategoryView.ReadOnly = true;
            this.dgrCategoryView.RowTemplate.Height = 24;
            this.dgrCategoryView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrCategoryView.Size = new System.Drawing.Size(671, 260);
            this.dgrCategoryView.TabIndex = 6;
            this.dgrCategoryView.SelectionChanged += new System.EventHandler(this.dgrCategoryView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // btnEssReceipt
            // 
            this.btnEssReceipt.Location = new System.Drawing.Point(47, 430);
            this.btnEssReceipt.Name = "btnEssReceipt";
            this.btnEssReceipt.Size = new System.Drawing.Size(93, 32);
            this.btnEssReceipt.TabIndex = 7;
            this.btnEssReceipt.Text = "Receipt";
            this.btnEssReceipt.UseVisualStyleBackColor = true;
            this.btnEssReceipt.Click += new System.EventHandler(this.btnEssReceipt_Click);
            // 
            // txtEssCategoryName
            // 
            this.txtEssCategoryName.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCategoryName.Location = new System.Drawing.Point(507, 44);
            this.txtEssCategoryName.Name = "txtEssCategoryName";
            this.txtEssCategoryName.Size = new System.Drawing.Size(210, 26);
            this.txtEssCategoryName.TabIndex = 11;
            // 
            // lblEssCategoryName
            // 
            this.lblEssCategoryName.AutoSize = true;
            this.lblEssCategoryName.Location = new System.Drawing.Point(362, 44);
            this.lblEssCategoryName.Name = "lblEssCategoryName";
            this.lblEssCategoryName.Size = new System.Drawing.Size(126, 23);
            this.lblEssCategoryName.TabIndex = 10;
            this.lblEssCategoryName.Text = "Category Name";
            // 
            // lblEssCount
            // 
            this.lblEssCount.AutoSize = true;
            this.lblEssCount.Location = new System.Drawing.Point(601, 430);
            this.lblEssCount.Name = "lblEssCount";
            this.lblEssCount.Size = new System.Drawing.Size(60, 23);
            this.lblEssCount.TabIndex = 12;
            this.lblEssCount.Text = "Count:";
            this.lblEssCount.Click += new System.EventHandler(this.lblEssCount_Click);
            // 
            // txtEssCount
            // 
            this.txtEssCount.HAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEssCount.Location = new System.Drawing.Point(667, 430);
            this.txtEssCount.Name = "txtEssCount";
            this.txtEssCount.Size = new System.Drawing.Size(50, 26);
            this.txtEssCount.TabIndex = 13;
            // 
            // btnEssExpense
            // 
            this.btnEssExpense.Location = new System.Drawing.Point(154, 430);
            this.btnEssExpense.Name = "btnEssExpense";
            this.btnEssExpense.Size = new System.Drawing.Size(93, 32);
            this.btnEssExpense.TabIndex = 14;
            this.btnEssExpense.Text = "Expense";
            this.btnEssExpense.UseVisualStyleBackColor = true;
            this.btnEssExpense.Click += new System.EventHandler(this.btnEssExpense_Click_1);
            // 
            // btnEssExport
            // 
            this.btnEssExport.Location = new System.Drawing.Point(480, 93);
            this.btnEssExport.Name = "btnEssExport";
            this.btnEssExport.Size = new System.Drawing.Size(93, 36);
            this.btnEssExport.TabIndex = 15;
            this.btnEssExport.Text = "Export";
            this.btnEssExport.UseVisualStyleBackColor = true;
            this.btnEssExport.Click += new System.EventHandler(this.btnEssExport_Click);
            // 
            // CategoryPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 474);
            this.Controls.Add(this.btnEssExport);
            this.Controls.Add(this.btnEssExpense);
            this.Controls.Add(this.txtEssCount);
            this.Controls.Add(this.lblEssCount);
            this.Controls.Add(this.txtEssCategoryName);
            this.Controls.Add(this.lblEssCategoryName);
            this.Controls.Add(this.btnEssReceipt);
            this.Controls.Add(this.dgrCategoryView);
            this.Controls.Add(this.txtEssCategoryID);
            this.Controls.Add(this.lblEssCategoryID);
            this.Controls.Add(this.btnEssClose);
            this.Controls.Add(this.btnEssClear);
            this.Controls.Add(this.btnEssDelete);
            this.Controls.Add(this.btnEssSave);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CategoryPage";
            this.Text = "Category Details";
            this.Load += new System.EventHandler(this.CategoryPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrCategoryView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private eSurvey.Controls.ESSButton btnEssSave;
        private eSurvey.Controls.ESSButton btnEssDelete;
        private eSurvey.Controls.ESSButton btnEssClear;
        private eSurvey.Controls.ESSButton btnEssClose;
        private eSurvey.Controls.ESSLabel lblEssCategoryID;
        private eSurvey.Controls.ESSTextBox txtEssCategoryID;
        private eSurvey.Controls.ESSGridView dgrCategoryView;
        private eSurvey.Controls.ESSButton btnEssReceipt;
        private eSurvey.Controls.ESSTextBox txtEssCategoryName;
        private eSurvey.Controls.ESSLabel lblEssCategoryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private eSurvey.Controls.ESSLabel lblEssCount;
        private eSurvey.Controls.ESSTextBox txtEssCount;
        private eSurvey.Controls.ESSButton btnEssExpense;
        private eSurvey.Controls.ESSButton btnEssExport;
    }
}