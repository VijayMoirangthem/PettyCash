﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using PettyCashApplication;
using PettyCashApp;
using ESSExcelExport;

namespace PettyCashApplication
{
    public partial class ReceiptPage : Form
    {
        private DataSet dataSet;
        private SQLiteDataAdapter adapter;
        private SQLiteConnection connection;
        private string strCS = @"URI=file:" + Application.StartupPath + "\\PettyCash.db";

        public ReceiptPage()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove maximize and minimize buttons, only close button should be visible
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            InitializeEssBoundGridView();
            dgrReceiptView.ClearSelection();
            txtEssCount.ReadOnly = true;
            UpdateCount();
        }

        private void ReceiptPage_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadPersons();
            UpdateCount();
            InitializeAdapter();
            ClearForm();
            dgrReceiptView.SelectionChanged += dgrReceiptView_SelectionChanged;
        }

        private void InitializeAdapter()
        {
            adapter = new SQLiteDataAdapter("SELECT * FROM Receipt", strCS);
            SQLiteCommandBuilder builder = new SQLiteCommandBuilder(adapter);

            adapter.InsertCommand = builder.GetInsertCommand();
            adapter.UpdateCommand = builder.GetUpdateCommand();
            adapter.DeleteCommand = builder.GetDeleteCommand();
        }

        private void InitializeEssBoundGridView()
        {
            dgrReceiptView.AutoGenerateColumns = false;
            dgrReceiptView.Columns.Clear();

            dgrReceiptView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ReceiptID",
                DataPropertyName = "ReceiptID",
                HeaderText = "Receipt ID",
                ReadOnly = true
            });
            dgrReceiptView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PersonName",
                DataPropertyName = "PersonName",
                HeaderText = "Person Name"
            });
            dgrReceiptView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Date",
                DataPropertyName = "Date",
                HeaderText = "Date"
            });
            dgrReceiptView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Amount",
                DataPropertyName = "Amount",
                HeaderText = "Amount"
            });
        }

        private void LoadData()
        {
            try
            {
                connection = new SQLiteConnection(strCS);
                string query = "SELECT r.ReceiptID, p.Name AS PersonName, r.Date, r.Amount " +
                               "FROM Receipt r " +
                               "JOIN Person p ON r.PersonID = p.PersonID";

                adapter = new SQLiteDataAdapter(query, connection);

                dataSet = new DataSet();
                adapter.Fill(dataSet, "Receipt");
                dataSet.Tables["Receipt"].PrimaryKey = new DataColumn[] { dataSet.Tables["Receipt"].Columns["ReceiptID"] };

                dgrReceiptView.DataSource = dataSet.Tables["Receipt"];
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }



        private void LoadPersons()
        {
            try
            {
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    SQLiteCommand command = new SQLiteCommand("SELECT PersonID, Name FROM Person", connection);
                    SQLiteDataReader reader = command.ExecuteReader();
                    DataTable personTable = new DataTable();
                    personTable.Load(reader);
                    cmbEssPerson.DisplayMember = "Name";
                    cmbEssPerson.ValueMember = "PersonID";
                    cmbEssPerson.DataSource = personTable;
                }
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading persons: " + ex.Message);
            }
        }

        private void btnEssSave_Click(object sender, EventArgs e)
        {
            if (IsNullOrWhiteSpace(txtEssReceiptID.Text))
            {
                MessageBox.Show("Please enter Receipt ID.");
                return;
            }

            if (cmbEssPerson.SelectedItem == null)
            {
                MessageBox.Show("Please select a Person.");
                return;
            }

            if (IsNullOrWhiteSpace(txtEssAmount.Text))
            {
                MessageBox.Show("Please enter the Amount.");
                return;
            }

            if (dgrReceiptView.SelectedRows.Count > 0)
            {
                UpdateData();
            }
            else
            {
                InsertData();
            }
        }

        private bool IsNullOrWhiteSpace(string value)
        {
            return string.IsNullOrEmpty(value) || value.Trim().Length == 0;
        }

        private void btnEssDelete_Click(object sender, EventArgs e)
        {
            if (dgrReceiptView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete?", "Delete data", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                return;
            }

            try
            {
                int selectedRowIndex = dgrReceiptView.SelectedRows[0].Index;
                int receiptID = Convert.ToInt32(dgrReceiptView.Rows[selectedRowIndex].Cells["ReceiptID"].Value);

                // Delete from database
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM Receipt WHERE ReceiptID = @ReceiptID", connection))
                    {
                        cmd.Parameters.AddWithValue("@ReceiptID", receiptID);
                        cmd.ExecuteNonQuery();
                    }
                }

                // Remove from dataset
                DataRow row = dataSet.Tables["Receipt"].Rows.Find(receiptID);
                if (row != null)
                {
                    row.Delete();
                    dataSet.Tables["Receipt"].AcceptChanges(); // Commit the deletion
                }

                // Refresh DataGridView
                dgrReceiptView.DataSource = dataSet.Tables["Receipt"];
                UpdateCount();
                ClearForm();
                MessageBox.Show("Receipt deleted successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Receipt deleted successfully.");
            }
        }

        private void InsertData()
        {
            try
            {
                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();

                    // Check if Receipt ID already exists
                    if (CheckIfExistsID(txtEssReceiptID.Text.Trim()))
                    {
                        MessageBox.Show("The Receipt ID already exists. Please enter a different ID.");
                        return;
                    }

                    string insertQuery = "INSERT INTO Receipt (ReceiptID, PersonID, Date, Amount) VALUES (@ReceiptID, @PersonID, @Date, @Amount)";
                    using (SQLiteCommand cmd = new SQLiteCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ReceiptID", Convert.ToInt32(txtEssReceiptID.Text));
                        cmd.Parameters.AddWithValue("@PersonID", cmbEssPerson.SelectedValue);
                        cmd.Parameters.AddWithValue("@Date", dtpEssDate.Value);
                        cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtEssAmount.Text));

                        cmd.ExecuteNonQuery();
                    }
                }

                LoadData();
                UpdateCount();
                ClearForm();
                MessageBox.Show("Receipt added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting receipt: " + ex.Message);
            }
        }

        private bool CheckIfExistsID(string value)
        {
            bool exists = false;
            string query = "SELECT COUNT(1) FROM Receipt WHERE ReceiptID = @value";

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(strCS))
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@value", value);
                        exists = Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking Receipt ID existence: " + ex.Message);
            }

            return exists;
        }


        private void UpdateData()
        {
            try
            {
                if (dgrReceiptView.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a row to update.");
                    return;
                }

                int oldReceiptID = Convert.ToInt32(dgrReceiptView.SelectedRows[0].Cells["ReceiptID"].Value);
                int newReceiptID = Convert.ToInt32(txtEssReceiptID.Text);

                using (connection = new SQLiteConnection(strCS))
                {
                    connection.Open();

                    if (oldReceiptID != newReceiptID && CheckIfExistsID(txtEssReceiptID.Text.Trim()))
                    {
                        MessageBox.Show("The new Receipt ID already exists. Please enter a different ID.");
                        return;
                    }

                    if (oldReceiptID != newReceiptID)
                    {
                        using (SQLiteTransaction transaction = connection.BeginTransaction())
                        {
                            try
                            {
                                string updateReceiptQuery = "UPDATE Receipt SET ReceiptID = @NewReceiptID, PersonID = @PersonID, Date = @Date, Amount = @Amount WHERE ReceiptID = @OldReceiptID";
                                using (SQLiteCommand cmd = new SQLiteCommand(updateReceiptQuery, connection, transaction))
                                {
                                    cmd.Parameters.AddWithValue("@NewReceiptID", newReceiptID);
                                    cmd.Parameters.AddWithValue("@OldReceiptID", oldReceiptID);
                                    cmd.Parameters.AddWithValue("@PersonID", cmbEssPerson.SelectedValue);
                                    cmd.Parameters.AddWithValue("@Date", dtpEssDate.Value);
                                    cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtEssAmount.Text));

                                    cmd.ExecuteNonQuery();
                                }

                                transaction.Commit();
                            }
                            catch (Exception)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }
                    else
                    {
                        string updateQuery = "UPDATE Receipt SET PersonID = @PersonID, Date = @Date, Amount = @Amount WHERE ReceiptID = @ReceiptID";
                        using (SQLiteCommand cmd = new SQLiteCommand(updateQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@ReceiptID", newReceiptID);
                            cmd.Parameters.AddWithValue("@PersonID", cmbEssPerson.SelectedValue);
                            cmd.Parameters.AddWithValue("@Date", dtpEssDate.Value);
                            cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtEssAmount.Text));

                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                LoadData();
                UpdateCount();
                ClearForm();
                MessageBox.Show("Receipt updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating receipt: " + ex.Message);
            }
        }


        
        private void UpdateCount()
        {
            if (dataSet != null && dataSet.Tables.Contains("Receipt"))
            {
                txtEssCount.Text = dataSet.Tables["Receipt"].Rows.Count.ToString();
            }
            else
            {
                txtEssCount.Text = "0";
            }
        }
        
        private void ClearForm()
        {
            txtEssReceiptID.Clear();
            cmbEssPerson.SelectedIndex = -1;
            dtpEssDate.Value = DateTime.Now;
            txtEssAmount.Clear();
            dgrReceiptView.ClearSelection();
            UpdateCount();
        }


        private void btnEssClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btnEssClose_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to close this Window?", "Close Application", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void dgrReceiptView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgrReceiptView.Rows[e.RowIndex];
                txtEssReceiptID.Text = row.Cells["ReceiptID"].Value.ToString();
                cmbEssPerson.Text = row.Cells["PersonName"].Value.ToString();
                dtpEssDate.Value = Convert.ToDateTime(row.Cells["Date"].Value);
                txtEssAmount.Text = row.Cells["Amount"].Value.ToString();
            }
        }

        private void cmbEssPerson_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Handle Person comboBox selection changes if needed
        }

        private void btnEssReceiptSearch_Click(object sender, EventArgs e)
        {
            ReceiptSearch receiptSearch = new ReceiptSearch();
            receiptSearch.Show();
            this.Hide();
        }

        private void btnEssCategory_Click(object sender, EventArgs e)
        {
            CategoryPage category = new CategoryPage();
            category.Show();
            this.Hide();
        }


        private void btnEsseExport_Click(object sender, EventArgs e)
        {
            string strFileName = @"E:\Current Files\PettyCash\PettyCashApplication\PettyCashApp\bin\Debug\ReceiptPageExportTemplate.xlsx";
            ExcelExport eport = new ExcelExport(ExcelAppType.MicrosoftExcel, false);
            eport.OpenWorkbook(strFileName);
            eport.SetVisible(false);
            DataTable dt = (DataTable)dgrReceiptView.DataSource;
            if (dt != null && dt.Rows.Count > 0)
            {
                int Rowspos = 2;
                foreach (DataRow row in dt.Select())
                {
                    eport.SetCellContent(Rowspos, 1, row[0]);
                    eport.SetCellContent(Rowspos, 2, row[1]);
                    eport.SetCellContent(Rowspos, 3, row[2]);
                    eport.SetCellContent(Rowspos, 4, row[3]);
                    Rowspos++;
                }
            }
            eport.SetVisible(true);
            MessageBox.Show("Export Success");

        }

        private void dgrReceiptView_SelectionChanged(object sender, EventArgs e)
        {
            if (dgrReceiptView.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgrReceiptView.SelectedRows[0];
                txtEssReceiptID.Text = row.Cells["ReceiptID"].Value.ToString();
                cmbEssPerson.Text = row.Cells["PersonName"].Value.ToString(); // Use "PersonName" instead of "Name"
                dtpEssDate.Value = Convert.ToDateTime(row.Cells["Date"].Value); // Use Value property for DateTime
                txtEssAmount.Text = row.Cells["Amount"].Value.ToString();
            }
        }


    }
}